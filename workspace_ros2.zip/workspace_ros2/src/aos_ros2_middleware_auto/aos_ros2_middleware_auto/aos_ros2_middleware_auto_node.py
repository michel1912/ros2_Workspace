#!/usr/bin/python3
import datetime
import rclpy
import pymongo
import traceback
import operator
import time
import threading  # Import threading module

from geometry_msgs.msg import Point
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from nav2_msgs.action import NavigateToPose
from interfaces_robot.srv import NavigateToCoordinates
from std_msgs.msg import Bool
from rcl_interfaces.msg import Log



DEBUG = False
HEAVY_LOCAL_VARS={}

aosDbConnection = pymongo.MongoClient("mongodb://localhost:27017/")
aosDB = aosDbConnection["AOS"]
aos_statisticsDB = aosDbConnection["AOS_Statistics"]
aos_local_var_collection = aosDB["LocalVariables"]
aosStats_local_var_collection = aos_statisticsDB["LocalVariables"]
aos_GlobalVariablesAssignments_collection = aosDB["GlobalVariablesAssignments"]
aos_ModuleResponses_collection = aosDB["ModuleResponses"]
collActionForExecution = aosDB["ActionsForExecution"]
collLogs = aosDB["Logs"]
collActions = aosDB["Actions"]

aos_local_var_collection1 = aosDB["LocalVariablesDB"]
aosStats_local_var_collection1 = aos_statisticsDB["LocalVariablesDB"]




def registerError(errorStr, trace, comments=None):
    error = {
        "Component": "RosMiddleware", "Event": errorStr, "Advanced": trace, "LogLevel": 2, "LogLevelDesc": "Error",
        "Time": datetime.datetime.utcnow()
    }
    if comments is not None:
        error = {
            "Component": "RosMiddleware", "Error": errorStr, "Advanced": str(comments) + ". " + str(trace),
            "Time": datetime.datetime.utcnow()
        }
    collLogs.insert_one(error)

def registerLog(logStr):
    log = {
        "Component": "RosMiddleware", "Event": logStr, "LogLevel": 5, "LogLevelDesc": "Debug", "Advanced": "",
        "Time": datetime.datetime.utcnow()
    }
    collLogs.insert_one(log)

def getHeavyLocalVarList(moduleName):
    return HEAVY_LOCAL_VARS.get(moduleName, [])





class ListenToMongoDbCommands(Node):
    def __init__(self, topic_listener, shared_state):
        super().__init__('listen_to_mongodb_commands')
        self.current_action_sequence_id = 1
        self.current_action_for_execution_id = None
        self.shared_state = shared_state
        self.navigate_service_name = "/navigate_to_coordinates"
        self._topicListener = topic_listener
        self.cli = self.create_client(NavigateToCoordinates, self.navigate_service_name)
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Service not available, waiting again...')
        self.timer = self.create_timer(1.0, self.listen_to_mongodb_commands)


    def handle_navigate(self, params):
        responseNotByLocalVariables = None
        nav_to_x = ""
        nav_to_y = ""
        nav_to_z = ""
        try:
            nav_to_x = params["ParameterValues"]["x"]
            self._topicListener.updateLocalVariableValue("nav_to_x", "", nav_to_x)
            nav_to_y = params["ParameterValues"]["y"]
            self._topicListener.updateLocalVariableValue("nav_to_y", "", nav_to_y)
            nav_to_z = params["ParameterValues"]["z"]
            self._topicListener.updateLocalVariableValue("nav_to_z", "", nav_to_z)
        except Exception as e:
            registerError(str(e), traceback.format_exc(), 'Action: navigate, illegalActionObs')
            responseNotByLocalVariables = "illegalActionObs"
            return responseNotByLocalVariables
        try:
            registerLog("wait for service: moduleName=navigate, serviceName=NavigateToCoordinates")
            req = NavigateToCoordinates.Request()
            req.x = float(nav_to_x)

            req.y = float(nav_to_y)

            req.z = float(nav_to_z)
            self.get_logger().info("Sending request to service, moduleName=navigate")
            future = self.cli.call_async(req)
            registerLog("Service call made, waiting for response")
            future.add_done_callback(self.navigate_callback)
            time.sleep(0.1)
        except Exception as e:
            registerError(str(e), traceback.format_exc(), 'Action: navigate')
            print("Service call failed")
        return responseNotByLocalVariables

    def navigate_callback(self, future):
        try:
            registerLog("navigate_callback invoked")
            result = future.result()
            registerLog("Future result obtained")
            if result is not None:
                skillSuccess = result.success  
                self._topicListener.updateLocalVariableValue("skillSuccess", "DB", skillSuccess)
                registerLog(f"Service response success: {skillSuccess}")
                if DEBUG:
                    print("navigate service terminated")
            else:
                self.get_logger().error("Service call failed, result is None")
                registerLog("Service call failed, result is None")
        except Exception as e:
            registerError(str(e), traceback.format_exc(), 'Action: navigate')
            print("Service call failed")

    

    def saveHeavyLocalVariableToDB(self, moduleName):
        for varName in getHeavyLocalVarList(moduleName):
            value = self._topicListener.localVarNamesAndValues[moduleName][varName]
            aos_local_var_collection.replace_one({"Module": moduleName, "VarName": varName},
                                                 {"Module": moduleName, "VarName": varName,
                                                  "Value": value}, upsert=True)
            aosStats_local_var_collection.insert_one(
                {"Module": moduleName, "VarName": varName, "value": value,
                 "Time": datetime.datetime.utcnow()})




    def registerModuleResponse(self, moduleName, startTime, actionSequenceID, responseNotByLocalVariables):
        registerLog("in the function registerModuleResponse:::::::: ")
        self._topicListener.initLocalVars(moduleName)  # Ensure initialization
        registerLog("in the function registerModuleResponse222222222222:::::::: ")

        self.saveHeavyLocalVariableToDB(moduleName)
        registerLog("in the function registerModuleResponse333333333333333:::::::: ")

        filter1 = {"ActionSequenceId": actionSequenceID}
        # if DEBUG:
            # print("registerModuleResponse()")

        if responseNotByLocalVariables is not None:
            moduleResponseItem = {"Module": moduleName, "ActionSequenceId": actionSequenceID,
                                  "ModuleResponseText": responseNotByLocalVariables, "StartTime": startTime,
                                  "EndTime": datetime.datetime.utcnow(),
                                  "ActionForExecutionId": self.current_action_for_execution_id}
            aos_ModuleResponses_collection.replace_one(filter1, moduleResponseItem, upsert=True)
            return
        registerLog("in the function registerModuleResponse444444444:::::::: ")
        # time.sleep(2)
        moduleResponse = ""
        assignGlobalVar = {}


        if moduleName == "navigate":
            registerLog("in the function registerModuleResponse for navigate:::::::: ")
            skillSuccess = self._topicListener.localVarNamesAndValues["navigate"]["skillSuccess"]
            registerLog("skillSuccess:  "  +  str(skillSuccess))
            goal_reached = self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]
            registerLog("goal_reached:  "  +  str(goal_reached))
            nav_to_x = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_x"]
            nav_to_y = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_y"]
            nav_to_z = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_z"]
            if moduleResponse == "" and  skillSuccess and goal_reached  :
                moduleResponse = "navigate_eSuccess"
            if moduleResponse == "" and  True  :
                moduleResponse = "navigate_eFailed"






        registerLog("this is the response of the navigation : "+moduleResponse)
        moduleLocalVars = self._topicListener.localVarNamesAndValues.get(moduleName, {})
        moduleResponseItem = {"Module": moduleName, "ActionSequenceId": actionSequenceID,
                              "ModuleResponseText": moduleResponse, "StartTime": startTime, "EndTime": datetime.datetime.utcnow(),
                              "ActionForExecutionId": self.current_action_for_execution_id,
                              "LocalVariables": moduleLocalVars}
        aos_ModuleResponses_collection.replace_one(filter1, moduleResponseItem, upsert=True)

        for varName, value in assignGlobalVar.items():
            isInit = value is not None
            aos_GlobalVariablesAssignments_collection.replace_one({"GlobalVariableName": varName},
                                                                  {"GlobalVariableName": varName, "LowLevelValue": value,
                                                                   "IsInitialized": isInit, "UpdatingActionSequenceId": actionSequenceID,
                                                                   "ModuleResponseId": moduleResponseItem["_id"]}, upsert=True)
    def reset_navigation_vars(self):
        self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"] = False
        self._topicListener.localVarNamesAndValues["navigate"]["skillSuccess"] = False

    def listen_to_mongodb_commands(self):
        filter1 = {"ActionSequenceId": self.current_action_sequence_id}
        actionForExecution = collActionForExecution.find_one(filter1)
        if actionForExecution:
            if DEBUG:
                print("~~")
                print("actionID:", actionForExecution["ActionID"])
            moduleName = actionForExecution["ActionName"]
            actionParameters = actionForExecution["Parameters"]
            self.current_action_for_execution_id = actionForExecution["_id"]
            registerLog("navigate start with id :::" + str(self.current_action_sequence_id))
            self._topicListener.setListenTarget(moduleName)
            time.sleep(0.3)
            moduleActivationStart = datetime.datetime.utcnow()
            responseNotByLocalVariables = None
            print("module name:", moduleName)
            registerLog("Request to call to module: " + moduleName)
            registerLog("navigate start:")


            if moduleName == "navigate":
                    print("handle navigate")
                    responseNotByLocalVariables = self.handle_navigate(actionParameters)
                    registerLog("navigate finished:")

            time.sleep(0.3)
           # self._topicListener.setListenTarget("after action")
            while not self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]:
                        rclpy.spin_once(self._topicListener, timeout_sec=0.1)
 
            registerLog("after while loop of goal reached"+ str(self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]))    
            self.registerModuleResponse(moduleName, moduleActivationStart, self.current_action_sequence_id,
                                        responseNotByLocalVariables)

            self.reset_navigation_vars()  # Reset navigation variables after processing the command

            if DEBUG:
                print("navigate finished")
            self.current_action_sequence_id += 1
            self.currentActionFotExecutionId = None
    time.sleep(0.1)

        
class AOS_TopicListenerServer(Node):
    def __init__(self, shared_state):
        super().__init__('aos_topic_listener_server')
        self.shared_state = shared_state
        self.localVarNamesAndValues = {"navigate":{"skillSuccess": False, "goal_reached": False, "nav_to_x": None, "nav_to_y": None, "nav_to_z": None}}
        self.setListenTarget("initTopicListener")
        self.subscription = self.create_subscription(Log, '/rosout', self.cb__rosout, 10)
        self.lock = threading.Lock()
        print("LOLO")
        self.get_logger().info("AOS_TopicListenerServer initialized and subscribed to /rosout")

    def cb__rosout(self, msg):
        try:
            print(self.listenTargetModule)
            if self.listenTargetModule == "navigate":
                if DEBUG:
                    print("handling topic call:navigate")
                    print(msg)
                #-----------------------------------------------------------------------
                value = self.navigate_get_value_goal_reached(msg)
                self.updateLocalVariableValue("goal_reached", "DB", value)
                #-----------------------------------------------------------------------
        except Exception as e:
            registerError(str(e), traceback.format_exc(), 'topic /rosout')

    def navigate_get_value_goal_reached(self, __input):
        if self.localVarNamesAndValues[self.listenTargetModule]["goal_reached"] == True:
            registerLog("11111111111111111111111111111111111111111111")
            return True
        else:
            return 'Goal succeeded' in __input.msg


    def initLocalVars(self, moduleNameToInit):
        for moduleName, localVarNamesAndValuesPerModule in self.localVarNamesAndValues.items():
            for localVarName, value in localVarNamesAndValuesPerModule.items():
                if moduleName == moduleNameToInit:
                    aos_local_var_collection.replace_one({"Module": moduleName, "VarName": localVarName},
                                                         {"Module": moduleName, "VarName": localVarName, "Value": value},
                                                         upsert=True)
                    aosStats_local_var_collection.insert_one(
                        {"Module": moduleName, "VarName": localVarName, "value": value, "Time": datetime.datetime.utcnow()})


    def setListenTarget(self, _listenTargetModule):
        self.initLocalVars(_listenTargetModule)
        if DEBUG:
            print('setListenTopicTargetModule:')
            print(_listenTargetModule)
        self.listenTargetModule = _listenTargetModule


    def updateLocalVariableValue(self, varName, Consistency, value):
     with self.lock:
        if DEBUG and varName not in getHeavyLocalVarList(self.listenTargetModule):
            print("update local var:")
            print(varName)
            print(value)
        if self.listenTargetModule not in self.localVarNamesAndValues:
            return
        if Consistency != "ROS":
         if varName == "goal_reached":
            if self.localVarNamesAndValues[self.listenTargetModule][varName] != value :
                if DEBUG:
                    print("ACTUAL UPDATE --------------------------------------------------------------------------")
                self.localVarNamesAndValues[self.listenTargetModule][varName] = value
                registerLog("this is the s_g_r: " + str(self.localVarNamesAndValues[self.listenTargetModule][varName]) + " and this is the varname " + str(varName) + " the consis " + str(Consistency))
                if varName not in getHeavyLocalVarList(self.listenTargetModule):
                    if Consistency == "DB":
                        document = aos_local_var_collection1.find_one({"VarName": "goal_reached"})
                        if document:
                            index = document.get("Index") + 1
                        else:
                            index = 1

                        registerLog("this is the index of goal_reached: " + str(index))

                        aos_local_var_collection1.replace_one({"Module": self.listenTargetModule, "VarName": varName},
                                                              {"Module": self.listenTargetModule, "VarName": varName, "Index": index, "Value": value}, upsert=True)
                        aosStats_local_var_collection1.insert_one(
                            {"Module": self.listenTargetModule, "VarName": varName, "value": value, "Time": datetime.datetime.utcnow()})
                    elif Consistency == "ROS":
                        self.set_parameters([rclpy.parameter.Parameter(varName, rclpy.Parameter.Type.BOOL, value)])
                    else:
                        aos_local_var_collection.replace_one({"Module": self.listenTargetModule, "VarName": varName},
                                                             {"Module": self.listenTargetModule, "VarName": varName, "Value": value}, upsert=True)
                        aosStats_local_var_collection.insert_one(
                            {"Module": self.listenTargetModule, "VarName": varName, "value": value, "Time": datetime.datetime.utcnow()})
                    if DEBUG:
                        print("WAS UPDATED --------------------------------------------------------------------------")
                self.shared_state.goal_reached = False
         else:
            if varName == "skillSuccess":
              registerLog("printinggggggggg : " + str(varName) + self.localVarNamesAndValues[self.listenTargetModule][varName] + "and this is the value we send " + str(value))
            if self.localVarNamesAndValues[self.listenTargetModule][varName] != value:
                if DEBUG:
                    print("ACTUAL UPDATE --------------------------------------------------------------------------")
                self.localVarNamesAndValues[self.listenTargetModule][varName] = value
                registerLog("this is the s_g_r: " + str(self.localVarNamesAndValues[self.listenTargetModule][varName]) + " and this is the varname " + str(varName) + " the consis " + str(Consistency))
                if varName not in getHeavyLocalVarList(self.listenTargetModule):
                    if Consistency == "DB":
                        aos_local_var_collection1.replace_one({"Module": self.listenTargetModule, "VarName": varName},
                                                              {"Module": self.listenTargetModule, "VarName": varName, "Value": value}, upsert=True)
                        aosStats_local_var_collection1.insert_one(
                            {"Module": self.listenTargetModule, "VarName": varName, "value": value, "Time": datetime.datetime.utcnow()})
                    elif Consistency == "ROS":
                         self.set_parameters([rclpy.parameter.Parameter(varName, rclpy.Parameter.Type.BOOL, value)])
                    else:
                        registerLog("this is the index of skill_success:")
                        aos_local_var_collection.replace_one({"Module": self.listenTargetModule, "VarName": varName},
                                                             {"Module": self.listenTargetModule, "VarName": varName, "Value": value}, upsert=True)
                        aosStats_local_var_collection.insert_one(
                            {"Module": self.listenTargetModule, "VarName": varName, "value": value, "Time": datetime.datetime.utcnow()})
                    if DEBUG:
                        print("WAS UPDATED --------------------------------------------------------------------------")
        else:
         current_value = self.localVarNamesAndValues[self.listenTargetModule][varName]
         if current_value != value:
          self.localVarNamesAndValues[self.listenTargetModule][varName] = value
          registerLog(f'Updated {varName} to {value} for module {self.listenTargetModule} with consistency {Consistency}')
          if varName == 'goal_reached':
            registerLog("this is goal reached check1111111111111111111111")
            self.set_parameters([rclpy.parameter.Parameter('goal_reached', rclpy.Parameter.Type.BOOL, value)])
            self.verify_param_update('goal_reached', value)
            self.shared_state.goal_reached = value
            self.get_logger().info(f'This is the GOAL_REACHED SHARED value: {value}')
            
          elif varName == 'skillSuccess':
           registerLog("this is skillSuccess  check122222222222222222222") 
           self.set_parameters([rclpy.parameter.Parameter('skillSuccess', rclpy.Parameter.Type.BOOL, value)])
           self.verify_param_update('skillSuccess', value)
          
          
    def verify_param_update(self, param_name, expected_value):
     time.sleep(0.1)  # Short delay to allow parameter server to update
     param_value = self.get_parameter(param_name).get_parameter_value().bool_value
     if param_value == expected_value:
        self.get_logger().info(f'{param_name} successfully updated to {expected_value}')
     else:
        self.get_logger().error(f'{param_name} update failed: expected {expected_value}, got {param_value}')

     # Add additional logging to trace the flow and values
     self.get_logger().info(f'Current value of goal_reached in shared state: {self.shared_state.goal_reached}')
     self.get_logger().info(f'Current value of goal_reached in parameter server: {param_value}')



class SharedState1:
  def __init__(self):
    self.goal_reached = False
    self.skill_success=False








def main(args=None):
    rclpy.init(args=args)
    shared_state = SharedState1()
    topic_listener = AOS_TopicListenerServer(shared_state)
    command_listener = ListenToMongoDbCommands(topic_listener,shared_state)

    topic_listener.get_logger().info("Nodes initialized and command_listener is about to spin")
    executor = MultiThreadedExecutor()
    executor.add_node(topic_listener)
    executor.add_node(command_listener)
    try:
        rclpy.spin(command_listener)  # Only spin the command_listener node
    except KeyboardInterrupt:
        pass
    finally:
        executor.shutdown()
        command_listener.destroy_node()
        topic_listener.destroy_node()
        rclpy.shutdown()




