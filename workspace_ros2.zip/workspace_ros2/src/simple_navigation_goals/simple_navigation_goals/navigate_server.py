# import rclpy
# from rclpy.action import ActionServer, GoalResponse
# from nav2_msgs.action import NavigateToPose
# from nav2_msgs.action import ComputePathToPose

# class NavigateToPoseActionServer:
#     def __init__(self):
#         self.node = rclpy.create_node('navigate_to_pose_action_server')
#         self.current_pose = None  # Initialize current_pose
#         self.action_server = ActionServer(
#             self.node,
#             NavigateToPose,
#             'NavigateToPose',
#             self.execute_callback
#         )
#         self.node.get_logger().info('NavigateToPose action server has been created.')

#     def execute_callback(self, goal_handle):
#         self.node.get_logger().info('Received goal request')
#         # a=ComputePathToPose()
#         # b=NavigateToPose()
            
#         # goal_handle.request.pose.header.frame_id='map'
#         # Get the goal pose
#         goal_pose = goal_handle.request.pose.pose.position

#         if self.current_pose is not None:
#             self.node.get_logger().info('Goal pose before navigation task: ({}, {}, {})'.format(
#                 self.current_pose.x, self.current_pose.y, self.current_pose.z))
#         # NavigateToPose.Goal().pose.header.frame_id='map'
#         # Update current_pose with the new goal pose
#         # goal_pose_map=NavigateToPose.Goal()
#         # goal_pose.pose.header.frame_id='map'
#         self.current_pose = goal_pose

#         # Execute navigation task

#         self.node.get_logger().info('Navigation task completed')

#         if self.current_pose is not None:
#             self.node.get_logger().info('Goal pose after navigation task: ({}, {}, {})'.format(
#                 self.current_pose.x, self.current_pose.y, self.current_pose.z))

#         # Return the result
#         result = NavigateToPose.Result()
#         feedback_msg=NavigateToPose.Feedback()
#         # Publish feedback
#         goal_handle.publish_feedback(feedback_msg)
  
#       # Set the goal state to succeeded
#         goal_handle.succeed()
#         return result


# def main(args=None):
#     rclpy.init(args=args)
#     navigate_to_pose_action_server = NavigateToPoseActionServer()
#     rclpy.spin(navigate_to_pose_action_server.node)
#     rclpy.shutdown()

# if __name__ == '__main__':
#     main()



# import rclpy
# from rclpy.action import ActionServer
# from nav2_msgs.action import NavigateToPose
# from geometry_msgs.msg import PoseStamped
# from nav_msgs.msg import Path
# from geometry_msgs.msg import Twist

# class NavigateToPoseActionServer:
#     def __init__(self):
#         self.node = rclpy.create_node('navigate_to_pose_action_server')
#         self.current_pose = None
#         self.action_server = ActionServer(
#             self.node,
#             NavigateToPose,
#             'NavigateToPose',
#             self.execute_callback
#         )
#         self.cmd_vel_publisher = self.node.create_publisher(Twist, 'cmd_vel', 10)
#         self.node.get_logger().info('NavigateToPose action server has been created.')

#     def execute_callback(self, goal_handle):
#         self.node.get_logger().info('Received goal request')

#         # Get the goal pose
#         goal_pose = goal_handle.request.pose

#         # Publish initial pose with frame ID 'map'
#         initial_pose = PoseStamped()
#         initial_pose.header.frame_id = 'map'
#         initial_pose.pose = goal_pose.pose
#         self.node.get_logger().info('Publishing initial pose: {}'.format(initial_pose))

#         # Execute navigation task
#         self.move_to_pose(initial_pose)

#         # Return the result
#         result = NavigateToPose.Result()
#         goal_handle.succeed()
#         return result

#     def move_to_pose(self, goal_pose):
#         # This is a placeholder function to send velocity commands to the robot's base
#         # In a real scenario, you need to implement path planning and control logic here
#         twist_msg = Twist()
#         # self.node.get_logger().info('Publishing initial pose 11: {}'.format(goal_pose.pose.position.x))
#         twist_msg.linear.x = goal_pose.pose.position.x  # Forward velocity
#         twist_msg.linear.y=goal_pose.pose.position.y
#         twist_msg.linear.z=goal_pose.pose.position.z
#         self.node.get_logger().info('Publishing initial pose #####: {}'.format(twist_msg.linear.x))
#         twist_msg.angular.z = 0.0  # No angular velocity
#         self.cmd_vel_publisher.publish(twist_msg)


# def main(args=None):
#     rclpy.init(args=args)
#     navigate_to_pose_action_server = NavigateToPoseActionServer()
#     rclpy.spin(navigate_to_pose_action_server.node)
#     rclpy.shutdown()

# if __name__ == '__main__':
#     main()





################################## navigate server #################################
# import time
# import sys

# from action_msgs.msg import GoalStatus
# from geometry_msgs.msg import PoseStamped
# from geometry_msgs.msg import PoseWithCovarianceStamped
# from lifecycle_msgs.srv import GetState
# from nav2_msgs.action import NavigateToPose

# import rclpy
# from rclpy.action import ActionClient
# from rclpy.node import Node
# from rclpy.qos import QoSDurabilityPolicy, QoSHistoryPolicy, QoSReliabilityPolicy
# from rclpy.qos import QoSProfile


# class BasicNavigator(Node):
#     def __init__(self):
#         super().__init__('basic_navigator')
#         self.initial_pose = PoseStamped()
#         self.goal_handle = None
#         self.result_future = None
#         self.feedback = None
#         self.status = None

#         amcl_pose_qos = QoSProfile(
#           durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
#           reliability=QoSReliabilityPolicy.RELIABLE,
#           history=QoSHistoryPolicy.KEEP_LAST,
#           depth=1)

#         self.initial_pose_received = False
#         self.nav_to_pose_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
#         self.model_pose_sub = self.create_subscription(PoseWithCovarianceStamped,
#                                                        'amcl_pose',
#                                                        self._amclPoseCallback,
#                                                        amcl_pose_qos)
#         self.initial_pose_pub = self.create_publisher(PoseWithCovarianceStamped,
#                                                       'initialpose',
#                                                       10)

#     def setInitialPose(self, initial_pose):
#         self.initial_pose_received = False
#         self.initial_pose = initial_pose
#         self._setInitialPose()

#     def goToPose(self, pose):
#         # Sends a NavToPose action request and waits for completion
#         self.debug("Waiting for 'NavigateToPose' action server")
#         while not self.nav_to_pose_client.wait_for_server(timeout_sec=1.0):
#             self.info("'NavigateToPose' action server not available, waiting...")

#         goal_msg = NavigateToPose.Goal()
#         goal_msg.pose = pose

#         self.info('Navigating to goal: ' + str(pose.pose.position.x) + ' ' +
#                       str(pose.pose.position.y) + '...')
#         send_goal_future = self.nav_to_pose_client.send_goal_async(goal_msg,
#                                                                    self._feedbackCallback)
#         rclpy.spin_until_future_complete(self, send_goal_future)
#         self.goal_handle = send_goal_future.result()

#         if not self.goal_handle.accepted:
#             self.error('Goal to ' + str(pose.pose.position.x) + ' ' +
#                            str(pose.pose.position.y) + ' was rejected!')
#             return False

#         self.result_future = self.goal_handle.get_result_async()
#         return True

#     def cancelNav(self):
#         self.info('Canceling current goal.')
#         if self.result_future:
#             future = self.goal_handle.cancel_goal_async()
#             rclpy.spin_until_future_complete(self, future)
#         return

#     def isNavComplete(self):
#         if not self.result_future:
#             # task was cancelled or completed
#             return True
#         rclpy.spin_until_future_complete(self, self.result_future, timeout_sec=0.10)
#         if self.result_future.result():
#             self.status = self.result_future.result().status
#             if self.status != GoalStatus.STATUS_SUCCEEDED:
#                 self.info('Goal with failed with status code: {0}'.format(self.status))
#                 return True
#         else:
#             print("ana hooonn")
#             # Timed out, still processing, not complete yet
#             return False

#         self.info('Goal succeeded!')
#         return True

#     def getFeedback(self):
#         return self.feedback

#     def getResult(self):
#         return self.status

#     def _amclPoseCallback(self, msg):
#         self.initial_pose_received = True
#         return

#     def _feedbackCallback(self, msg):
#         self.feedback = msg.feedback
#         return

#     def _setInitialPose(self):
#         msg = PoseWithCovarianceStamped()
#         msg.pose.pose = self.initial_pose.pose
#         msg.header = self.initial_pose.header
#         self.info('Publishing Initial Pose')
#         self.initial_pose_pub.publish(msg)
#         return

#     def info(self, msg):
#         self.get_logger().info(msg)
#         return

#     def warn(self, msg):
#         self.get_logger().warn(msg)
#         return

#     def error(self, msg):
#         self.get_logger().error(msg)
#         return

#     def debug(self, msg):
#         self.get_logger().debug(msg)
#         return

# def main(argv=sys.argv[1:]):
#     rclpy.init()
#     navigator = BasicNavigator()

#     # Set our demo's initial pose
#     # initial_pose = PoseStamped()
#     # initial_pose.header.frame_id = 'map'
#     # initial_pose.pose.position.x = 0.036
#     # initial_pose.pose.position.y = 0.009
#     # initial_pose.pose.orientation.z = -0.010
#     # initial_pose.pose.orientation.w = 0.99
#     # navigator.setInitialPose(initial_pose)

#     # Go to our demos first goal pose
#     goal_pose = PoseStamped()
#     goal_pose.header.frame_id = 'map'
#     goal_pose.pose.position.x = 2.298
#     goal_pose.pose.position.y = -1.388
#     goal_pose.pose.orientation.w = 0.78
    
#     navigator.goToPose(goal_pose)
    
#     while not navigator.isNavComplete():
#      time.sleep(10)

    
#     result = navigator.getResult()
#     if result == GoalStatus.STATUS_SUCCEEDED:
#         print('Goal succeeded!')
#     elif result == GoalStatus.STATUS_CANCELED:
#         print('Goal was canceled!')
#     elif result == GoalStatus.STATUS_ABORTED:
#         print('Goal failed!')
#     else:
#         print('Goal has an invalid return status!')

#     rclpy.shutdown()

# if __name__ == '__main__':
#     main()





################################################################################


import time
import sys

from action_msgs.msg import GoalStatus
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose
from simple_navigation_goals.srv import NavigateToCoordinates

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node


class BasicNavigator(Node):
    def __init__(self):
        super().__init__('basic_navigator')
        self.nav_to_pose_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self.srv = self.create_service(NavigateToCoordinates, 'navigate_to_pose', self.handle_navigate)

    def handle_navigate(self, request, response):
        self.get_logger().info(f'Received goal: x={request.goal.x}, y={request.goal.y}, z={request.goal.z}')
        
        goal_pose = PoseStamped()
        goal_pose.header.frame_id = 'map'
        goal_pose.header.stamp = self.get_clock().now().to_msg()
        goal_pose.pose.position.x = request.goal.x
        goal_pose.pose.position.y = request.goal.y
        goal_pose.pose.position.z = request.goal.z
        goal_pose.pose.orientation.w = 1.0
        
        if self.goToPose(goal_pose):
            while not self.is_nav_complete():
                time.sleep(1)
            result = self.get_result()
            response.success = (result == GoalStatus.STATUS_SUCCEEDED)
        else:
            response.success = False

        return response

    # def go_to_pose(self, pose):
    #     self.get_logger().info('Waiting for "NavigateToPose" action server...')
    #     if not self.nav_to_pose_client.wait_for_server(timeout_sec=10.0):
    #         self.get_logger().error('"NavigateToPose" action server not available.')
    #         return False

    #     goal_msg = NavigateToPose.Goal()
    #     goal_msg.pose = pose

    #     self.get_logger().info(f'Navigating to goal: {pose.pose.position.x}, {pose.pose.position.y}...')
    #     self._send_goal_future = self.nav_to_pose_client.send_goal_async(goal_msg)
    #     rclpy.spin_until_future_complete(self, self._send_goal_future)
    #     self.goal_handle = self._send_goal_future.result()

    #     if not self.goal_handle.accepted:
    #         self.get_logger().error('Goal was rejected by the action server.')
    #         return False

    #     self._result_future = self.goal_handle.get_result_async()
    #     return True
    
    def goToPose(self, pose):
        # Sends a NavToPose action request and waits for completion
        self.debug("Waiting for 'NavigateToPose' action server")
        while not self.nav_to_pose_client.wait_for_server(timeout_sec=1.0):
            self.info("'NavigateToPose' action server not available, waiting...")

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = pose

        self.info('Navigating to goal: ' + str(pose.pose.position.x) + ' ' +
                      str(pose.pose.position.y) + '...')
        send_goal_future = self.nav_to_pose_client.send_goal_async(goal_msg)
        rclpy.spin_until_future_complete(self, send_goal_future)
        self.goal_handle = send_goal_future.result()

        if not self.goal_handle.accepted:
            self.error('Goal to ' + str(pose.pose.position.x) + ' ' +
                           str(pose.pose.position.y) + ' was rejected!')
            return False

        self.result_future = self.goal_handle.get_result_async()
        return True

    def is_nav_complete(self):
        if not self._result_future:
            return True
        rclpy.spin_until_future_complete(self, self._result_future, timeout_sec=0.1)
        if self._result_future.result():
            self._status = self._result_future.result().status
            if self._status != GoalStatus.STATUS_SUCCEEDED:
                self.get_logger().info(f'Goal failed with status code: {self._status}')
                return True
        return False

    def get_result(self):
        return self._status


def main(argv=sys.argv[1:]):
    rclpy.init()
    navigator = BasicNavigator()
    
    rclpy.spin(navigator)
    
    rclpy.shutdown()


if __name__ == '__main__':
    main()
