
##################################this code is work
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from interfaces_robot.srv import NavigateToCoordinates
from rcl_interfaces.msg import Log
from rclpy.action.server import ServerGoalHandle
import time

class NavigateToCoordinatesService(Node):
    def __init__(self):
        super().__init__('navigate_to_coordinates_service')
        self.get_logger().info("Service Initializing...")
        self.nav_pub = self.create_publisher(PoseStamped, '/goal_pose', 10)
        self.srv = self.create_service(NavigateToCoordinates, 'navigate_to_coordinates', self.navigate_to_coordinates_callback)

    def navigate_to_coordinates_callback(self, request, response):
        x = request.x
        y = request.y
        z = request.z
        self.get_logger().info(f'Received coordinates: x={x}, y={y}, z={z}')

        # Determine whether to accept or reject the goal
        if self.is_goal_acceptable(x, y, z):
            self.target_pose = PoseStamped()
            self.target_pose.header.frame_id = 'map'
            self.target_pose.pose.position.x = x
            self.target_pose.pose.position.y = y
            self.target_pose.pose.position.z = z
            self.target_pose.pose.orientation.w = 1.0

            self.get_logger().info('Sending goal...')
            self.nav_pub.publish(self.target_pose)

            # Here, you can add the logic to wait for the goal to be reached
            self.get_logger().info('Goal has been accepted.')
            response.success = True
            #response.succeed()
        else:
            self.get_logger().info('Goal has been rejected.')
            response.success = False
            #response.abort()

        return response
    


    def is_goal_acceptable(self, x, y, z):
        # Check if any coordinate is None, or i x or y is out of the map
        if x >= 3.0  or y >=3.0 or x <= -3.0  or y <=-3.0 or z is None:
            return False
        return True


def main(args=None):
    rclpy.init(args=args)
    command_listener = NavigateToCoordinatesService()

    command_listener.get_logger().info("Nodes initialized. Only command_listener will be spun.")

    try:
        rclpy.spin(command_listener)  # Only spin the command_listener node
    except KeyboardInterrupt:
        pass
    finally:
        command_listener.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
