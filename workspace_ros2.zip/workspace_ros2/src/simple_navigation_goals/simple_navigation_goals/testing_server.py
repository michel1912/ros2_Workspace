# # from nav2_msgs.action import NavigateToPose
# # from action_msgs.msg import GoalStatus

# # import rclpy
# # from rclpy.action import ActionClient
# # from rclpy.action import ActionServer
# # from rclpy.node import Node
# # from example_interfaces.srv import AddTwoInts




# # class NavigateToPoseNode(Node):

# #     def __init__(self):
# #         super().__init__('move_to_spot')
# #         server_test=self.create_service(NavigateToPose,"NavigateToPose",self.call_back_NavigateToPose)



# #     def call_back_NavigateToPose(self,request,response):
# #     # print("1")
# #     # goal_pose = NavigateToPose.Goal()
# #     # goal_pose.pose.header.frame_id = 'map'
# #     # goal_pose.pose.pose.position.x = 10.0
# #     # goal_pose.pose.pose.position.y = -2.0
# #     # goal_pose.pose.pose.position.z = 0.0
# #     # goal_pose.pose.pose.orientation.x = 0.0
# #     # goal_pose.pose.pose.orientation.y = 0.0
# #     # goal_pose.pose.pose.orientation.z = 0.0
# #     # goal_pose.pose.pose.orientation.w = 1.0
# #     # print("2")
# #     # print(goal_pose)
# #     # result_pose=NavigateToPose.Result()
# #     # result_pose.result
# #     #  response.sum=request.a + request.b
# #      print("1")
# #     #  return response
    


# # def main(args=None):
# #     rclpy.init(args=args)
# #     # node=Node("testing_server")
# #     # client_test=node.create_client(AddTwoInts,"NavigateToPose")
# #     # server_test=ActionServer(node,AddTwoInts,"NavigateToPose",call_back_NavigateToPose())
# #     node=NavigateToPoseNode()
# #     # action_server = NavToPoseActionServer()
# #     rclpy.spin(node)
# #     rclpy.shutdown()

# # if __name__ == '__main__':
# #     main()
# import rclpy
# from nav2_msgs.action import NavigateToPose,ComputePathToPose
# from rclpy.node import Node
# from example_interfaces.srv import AddTwoInts
# from rclpy.action import ActionServer


# class NavigateToPoseNode(Node):
#     def __init__(self):
#         super().__init__('move_to_spot')
#         self.get_logger().info('Initializing NavigateToPoseNode...')
#         # self.server_test = self.create_service(ComputePathToPose, "navigate_to_pose", self.call_back_NavigateToPose)

#         self.get_logger().info('Service server created.')

#     def call_back_NavigateToPose(self, request, response):
#         self.get_logger().info('Received NavigateToPose request')
#         self.get_logger().info('Request: {}'.format(request))
#         response = NavigateToPose.Response()  # Create a response message
#         # Populate the response message as needed
#         return response

# def main(args=None):
#     rclpy.init(args=args)
#     node = NavigateToPoseNode()
#     rclpy.spin(node)
#     rclpy.shutdown()

# if __name__ == '__main__':
#     main()

# import rclpy
# from rclpy.action import ActionServer
# from nav2_msgs.action import NavigateToPose
# from builtin_interfaces.msg import Duration
# # from nav2_msgs.action/NavigateToPose import NavigateToPose_Goal, NavigateToPose_Feedback, NavigateToPose_Result

# class NavigateToPoseActionServer:
#     def __init__(self):
#         self.node = rclpy.create_node('navigate_to_pose_action_server')
#         self.action_server = ActionServer(
#             self.node,
#             NavigateToPose,
#             'NavigateToPose',
#             self.execute_callback
#         )
#         self.node.get_logger().info('NavigateToPose action server has been created.')

#     async def execute_callback(self, goal_handle):
#         self.node.get_logger().info('Received goal request')
#         # Initialize feedback and result objects
#         feedback_msg=NavigateToPose.Feedback()
#         # feedback_msg = NavigateToPose_Feedback()
#         result_msg=NavigateToPose.Result()
#         # result_msg = NavigateToPose_Result()

#         # Execute your navigation task here
#         # For demonstration purposes, let's assume the task succeeds immediately
#         feedback_msg.navigation_time = self.node.get_clock().now().to_msg()
#         feedback_msg.number_of_recoveries = 0
#         feedback_msg.distance_remaining = 0.0
#         feedback_msg.navigation_time=Duration()

#         # Publish result
#         goal_handle.succeed(feedback_msg)

#         self.node.get_logger().info('Navigation task completed')

# def main(args=None):
#     rclpy.init(args=args)
#     navigate_to_pose_action_server = NavigateToPoseActionServer()
#     rclpy.spin(navigate_to_pose_action_server.node)
#     rclpy.shutdown()

# if __name__ == '__main__':
#     main()



import rclpy
from rclpy.action import ActionServer
from nav2_msgs.action import NavigateToPose
from builtin_interfaces.msg import Duration

class NavigateToPoseActionServer:
    def __init__(self):
        self.node = rclpy.create_node('navigate_to_pose_action_server')
        self.action_server = ActionServer(
            self.node,
            NavigateToPose,
            '/navigate_to_pose',
            self.execute_callback
        )
        self.node.get_logger().info('NavigateToPose action server has been created.')

    def execute_callback(self, goal_handle):
      self.node.get_logger().info('Received goal request')
    #   self.node.get_logger().info()
      goal_pose = NavigateToPose.Feedback()
      
      self.node.get_logger().info(f'Goal pose before navigation task: {goal_pose.current_pose.pose}')
      # Initialize feedback and result objects
      feedback_msg = NavigateToPose.Feedback()
      result_msg = NavigateToPose.Result()

  
      # Execute your navigation task here
      # For demonstration purposes, let's assume the task succeeds immediately
      feedback_msg.navigation_time = Duration()
      feedback_msg.navigation_time.sec = 10  # Set the seconds component of the duration
      feedback_msg.navigation_time.nanosec = 0  # Set the nanoseconds component of the duration
      feedback_msg.number_of_recoveries = 0
      feedback_msg.distance_remaining = 0.0
  
      # Publish feedback
      goal_handle.publish_feedback(feedback_msg)
  
      # Set the goal state to succeeded
      goal_handle.succeed()

      self.node.get_logger().info('Navigation task completed')
      
    #   print(NavigateToPose.Goal().pose)
    #   self.node.get_logger().info(f'Goal pose after navigation task: {goal_pose.current_pose.pose}')

      return result_msg  


def main(args=None):
    rclpy.init(args=args)
    navigate_to_pose_action_server = NavigateToPoseActionServer()
    rclpy.spin(navigate_to_pose_action_server.node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()

