
import rclpy
from rclpy.action import ActionServer
from nav2_msgs.action import NavigateToPose
from builtin_interfaces.msg import Duration
from rclpy.node import Node
from rclpy.action.server import ServerGoalHandle
from interfaces_robot.srv import NavigateToCoordinates


class NavigateToPoseActionServer(Node):
    def __init__(self):
        self.node = rclpy.create_node('navigate_to_pose_server')
        # self.server_= self.create_service(NavigateToCoordinates,"navigate_to_coordinates",self.navigate_to_coordinates_callback())
        self.action_srv= ActionServer(self,NavigateToCoordinates,"navigate_to_coordinates",execute_callback=self.execute_callback)
        # self.action_srv.
        self.get_logger().info("Service Initializing...")

        self.node.get_logger().info(' action server has been created.')

    def execute_callback(self,goal_handle:ServerGoalHandle):    
     #get request from the goal
        x = goal_handle.request.x
        y = goal_handle.request.y
        z = goal_handle.request.z
      # execute the action :
        self.get_logger().info("execute the action ...")
        goal=NavigateToPose()
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = 'map'
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.pose.position.x = x
        goal_msg.pose.pose.position.y = y
        goal_msg.pose.pose.position.z = z
        goal_msg.pose.pose.orientation.w = 1.0
        
        pass

    # def navigate_to_coordinates_callback(self, request,response):
    #     x = request.x
    #     y = request.y
    #     z = request.z
    #     goal=NavigateToPose()
    #     goal_msg = NavigateToPose.Goal()
    #     goal_msg.pose.header.frame_id = 'map'
    #     goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
    #     goal_msg.pose.pose.position.x = x
    #     goal_msg.pose.pose.position.y = y
    #     goal_msg.pose.pose.position.z = z
    #     goal_msg.pose.pose.orientation.w = 1.0
        
        

def main(args=None):
    rclpy.init(args=args)
    navigate_to_pose_action_server = NavigateToPoseActionServer()
    rclpy.spin(navigate_to_pose_action_server)
    rclpy.shutdown()

if __name__ == '__main__':
    main()

