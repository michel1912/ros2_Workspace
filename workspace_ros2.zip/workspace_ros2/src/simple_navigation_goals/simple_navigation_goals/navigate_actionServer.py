from nav2_msgs.action import NavigateToPose
from action_msgs.msg import GoalStatus

import rclpy
from rclpy.action import ActionServer
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose

class NavToPoseActionServer(Node):

    def __init__(self):
        super().__init__('navigate_to_pose_action_server')
        # self._action_server =  ActionServer(
        #     self,
        #     NavigateToPose,
        #     'navigate_to_pose',
        #     self.execute_callback
        # )
        self._action_server=self.create_service(NavigateToPose,"navigate_to_pose",self.execute_callback) 
       
        self.get_logger().info('NavigateToPose Action Server is up and running.')

    def execute_callback(self, goal_handle):
        # print("!")
        self.get_logger().info('Received goal request')

        # Process the goal request here
        goal = goal_handle.request.goal.pose
        # For demonstration purposes, let's print the goal coordinates
        self.get_logger().info(f"Received goal: {goal.position.x}, {goal.position.y}, {goal.position.z}")

        # You can implement your navigation logic here
        # For now, let's just consider the goal succeeded
        goal_handle.succeed()

def main(args=None):
    rclpy.init(args=args)
    action_server = NavToPoseActionServer()
    rclpy.spin(action_server)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
