import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseWithCovarianceStamped

class InitialPosePublisher(Node):
    def __init__(self):
        super().__init__('initial_pose_publisher')
        self.publisher_ = self.create_publisher(PoseWithCovarianceStamped, 'initialpose', 10)
        timer_period = 2.0  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.declare_parameter('initial_pose_x', 0.0)
        self.declare_parameter('initial_pose_y', 0.0)
        self.declare_parameter('initial_pose_z', 0.0)
        self.declare_parameter('initial_pose_yaw', 0.0)

    def timer_callback(self):
        msg = PoseWithCovarianceStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'map'
        msg.pose.pose.position.x = self.get_parameter('initial_pose_x').get_parameter_value().double_value
        msg.pose.pose.position.y = self.get_parameter('initial_pose_y').get_parameter_value().double_value
        msg.pose.pose.position.z = self.get_parameter('initial_pose_z').get_parameter_value().double_value
        msg.pose.pose.orientation.w = 1.0  # Assuming no rotation, you might want to calculate this from yaw
        msg.pose.covariance = [0.0] * 36
        self.publisher_.publish(msg)
        self.get_logger().info('Published initial pose')

def main(args=None):
    rclpy.init(args=args)
    node = InitialPosePublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()


#####################THEEEE LAUNCHHHH FILEEEEEE####################

# from launch import LaunchDescription
# from launch_ros.actions import Node
# from launch.actions import IncludeLaunchDescription
# from launch.launch_description_sources import PythonLaunchDescriptionSource
# from ament_index_python.packages import get_package_share_directory

# def generate_launch_description():
#     ld = LaunchDescription()

#     # Include turtlebot3 world launch
#     turtlebot3_gazebo_launch = IncludeLaunchDescription(
#         PythonLaunchDescriptionSource([get_package_share_directory('turtlebot3_gazebo'), '/launch/turtlebot3_world.launch.py'])
#     )
#     ld.add_action(turtlebot3_gazebo_launch)

#     # Include turtlebot3 navigation2 launch
#     turtlebot3_navigation2_launch = IncludeLaunchDescription(
#         PythonLaunchDescriptionSource([get_package_share_directory('turtlebot3_navigation2'), '/launch/navigation2.launch.py']),
#         launch_arguments={'map_file': '$/home/map.yaml'}.items()
#     )
#     ld.add_action(turtlebot3_navigation2_launch)

#     # Add navigate_server node
#    # ld.add_action(Node(
#     #    package='simple_navigation_goals',
#      #   executable='navigate_server',
#       #  name='navigate_server',
#     #    output='screen'
#      # ))
#     # Add initial pose publisher node
#     initial_pose_publisher = Node(
#         package='simple_navigation_goals',  # Replace with your package name
#         executable='initial_pose_publisher',  # Replace with your script name
#         name='initial_pose_publisher',
#         output='screen'
#     )
#     ld.add_action(initial_pose_publisher)

#     return ld

