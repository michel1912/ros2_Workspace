from nav2_msgs.action import NavigateToPose
from action_msgs.msg import GoalStatus

import rclpy
from rclpy.action import ActionClient
from rclpy.action import ActionServer
from rclpy.node import Node
from example_interfaces.srv import AddTwoInts









def main(args=None):
    rclpy.init(args=args)
    node=Node("testing_client")
    # client_test=node.create_client(AddTwoInts,"NavigateToPose")
    client_test=ActionClient(node,NavigateToPose,"NavigateToPose")
    while not client_test.wait_for_server(1.0):
        node.get_logger().warn("Waiting for server Navigate To Pose")
    # action_server = NavToPoseActionServer()
    # rclpy.spin(client_test)
    rclpy.shutdown()

if __name__ == '__main__':
    main()

