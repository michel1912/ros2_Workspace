import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseWithCovarianceStamped

class InitialPosePublisher(Node):
    def __init__(self):
        super().__init__('initial_pose_publisher')
        self.publisher_ = self.create_publisher(PoseWithCovarianceStamped, 'initialpose', 10)
        self.timer = self.create_timer(1.0, self.timer_callback)
        self.publish_count = 0
        self.max_publish_count = 1  # Publish the pose once

    def timer_callback(self):
        if self.publish_count < self.max_publish_count:
            pose = PoseWithCovarianceStamped()
            pose.header.frame_id = 'map'
            pose.pose.pose.position.x = -1.6515159606933594
            pose.pose.pose.position.y = -1.4597514867782593
            pose.pose.pose.position.z = 0.0
            pose.pose.pose.orientation.z = 0.0  # Adjust this as needed
            pose.pose.pose.orientation.w = 1.0
            pose.pose.covariance = [0.0] * 36
            self.publisher_.publish(pose)
            self.get_logger().info('Publishing initial pose')
            self.publish_count += 1
        else:
            self.timer.cancel()

def main(args=None):
    rclpy.init(args=args)
    initial_pose_publisher = InitialPosePublisher()
    rclpy.spin(initial_pose_publisher)
    initial_pose_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
