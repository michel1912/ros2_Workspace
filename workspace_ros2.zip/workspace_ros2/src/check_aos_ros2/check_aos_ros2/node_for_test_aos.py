# import datetime
# import rclpy
# from rclpy.node import Node
# from rclpy.action import ActionClient
# import pymongo
# import time
# import traceback
# from geometry_msgs.msg import Point
# from nav2_msgs.action import NavigateToPose
# from rcl_interfaces.msg import Log
# from interfaces_robot.srv import NavigateToCoordinates
# from rclpy.executors import MultiThreadedExecutor
# TEMP=False
# DEBUG = True
# HEAVY_LOCAL_VARS = {}
# aosDbConnection = pymongo.MongoClient("mongodb://localhost:27017/")
# aosDB = aosDbConnection["AOS"]
# aos_statisticsDB = aosDbConnection["AOS_Statistics"]
# aos_local_var_collection = aosDB["LocalVariables"]
# aosStats_local_var_collection = aos_statisticsDB["LocalVariables"]
# aos_GlobalVariablesAssignments_collection = aosDB["GlobalVariablesAssignments"]
# aos_ModuleResponses_collection = aosDB["ModuleResponses"]
# collActionForExecution = aosDB["ActionsForExecution"]
# collLogs = aosDB["Logs"]
# collActions = aosDB["Actions"]

# def registerError(errorStr, trace, comments=None):
#     error = {
#         "Component": "RosMiddleware", "Event": errorStr, "Advanced": trace, "LogLevel": 2, "LogLevelDesc": "Error",
#         "Time": datetime.datetime.utcnow()
#     }
#     if comments is not None:
#         error = {
#             "Component": "RosMiddleware", "Error": errorStr, "Advanced": str(comments) + ". " + str(trace),
#             "Time": datetime.datetime.utcnow()
#         }
#     collLogs.insert_one(error)

# def registerLog(logStr):
#     log = {
#         "Component": "RosMiddleware", "Event": logStr, "LogLevel": 5, "LogLevelDesc": "Debug", "Advanced": "",
#         "Time": datetime.datetime.utcnow()
#     }
#     collLogs.insert_one(log)

# def getHeavyLocalVarList(moduleName):
#     return HEAVY_LOCAL_VARS.get(moduleName, [])

# class ListenToMongoDbCommands(Node):
#     def __init__(self, topic_listener):
#         super().__init__('listen_to_mongodb_commands')
#         self.current_action_sequence_id = 1
#         self.current_action_for_execution_id = None
#         self.navigate_service_name = "/navigate_to_coordinates"
#         self._topicListener = topic_listener
#         self.cli = self.create_client(NavigateToCoordinates, self.navigate_service_name)
        
#         while not self.cli.wait_for_service(timeout_sec=1.0):
#             self.get_logger().info('Service not available, waiting again...')

#         # Schedule periodic execution of the method
#         self.timer = self.create_timer(1.0, self.listen_to_mongodb_commands)

#     def handle_navigate(self, params):
#         responseNotByLocalVariables = None
#         nav_to_x, nav_to_y, nav_to_z = "", "", ""
#         try:
#             nav_to_x = params["ParameterValues"]["x"]
#             self._topicListener.updateLocalVariableValue("nav_to_x", nav_to_x)
#             nav_to_y = params["ParameterValues"]["y"]
#             self._topicListener.updateLocalVariableValue("nav_to_y", nav_to_y)
#             nav_to_z = params["ParameterValues"]["z"]
#             self._topicListener.updateLocalVariableValue("nav_to_z", nav_to_z)
#         except Exception as e:
#             registerError(str(e), traceback.format_exc(), 'Action: navigate, illegalActionObs')
#             responseNotByLocalVariables = "illegalActionObs"
    
#         try:
#             registerLog("wait for service: moduleName=navigate, serviceName=navigate")
#             req = NavigateToCoordinates.Request()
#             req.x = float(nav_to_x)
#             req.y = float(nav_to_y)
#             req.z = float(nav_to_z)
#             log_message = f"Request coordinates: x={req.x}, y={req.y}, z={req.z}"
#             registerLog("the goal now is :::" + log_message)
#             self.get_logger().info("Sending request to service, moduleName=navigate")
            
#             # Call the service asynchronously
#             future = self.cli.call_async(req)
#             registerLog("after call async:::::::::::")
            
#             # Spin until the future is complete or timeout occurs
#             while not TEMP:
#                 self.get_logger().info("Waiting for future to complete...")
#                 rclpy.spin_once(self, timeout_sec=0.1)
#             TEMP=False
#             registerLog("future is completed::::::::::")
            
#             # Check the result of the future
#             if future.result() is not None:
#                 self.get_logger().info("Service response received, moduleName=navigate")
#                 skillSuccess = future.result().success
#                 registerLog(f"the skillSuccess is ::::{skillSuccess}")
#                 self._topicListener.updateLocalVariableValue("skillSuccess", skillSuccess)
#                 registerLog("after the update of local variable value skillSuccess")
#                 if DEBUG:
#                     print("navigate service terminated")
#             else:
#                 self.get_logger().error("Service call failed")
#                 registerLog("Service call failed: Future returned None")
#         except Exception as e:
#             registerError(str(e), traceback.format_exc(), 'Action: navigate')
#             print("Service call failed")
#         registerLog("done from function handle navigate")
#         return responseNotByLocalVariables
    


#     def saveHeavyLocalVariableToDB(self, moduleName):
#         for varName in getHeavyLocalVarList(moduleName):
#             value = self._topicListener.localVarNamesAndValues[moduleName][varName]
#             aos_local_var_collection.replace_one({"Module": moduleName, "VarName": varName},
#                                                  {"Module": moduleName, "VarName": varName,
#                                                   "Value": value}, upsert=True)
#             aosStats_local_var_collection.insert_one(
#                 {"Module": moduleName, "VarName": varName, "value": value,
#                  "Time": datetime.datetime.utcnow()})

#     def registerModuleResponse(self, moduleName, startTime, actionSequenceID, responseNotByLocalVariables):
#         # self._topicListener.initLocalVars(moduleName)  # Ensure initialization
#         self.saveHeavyLocalVariableToDB(moduleName)
#         filter1 = {"ActionSequenceId": actionSequenceID}
#         if DEBUG:
#             print("registerModuleResponse()")

#         if responseNotByLocalVariables is not None:
#             moduleResponseItem = {"Module": moduleName, "ActionSequenceId": actionSequenceID,
#                                   "ModuleResponseText": responseNotByLocalVariables, "StartTime": startTime,
#                                   "EndTime": datetime.datetime.utcnow(),
#                                   "ActionForExecutionId": self.current_action_for_execution_id}
#             aos_ModuleResponses_collection.replace_one(filter1, moduleResponseItem, upsert=True)
#             return

#         moduleResponse = ""
#         assignGlobalVar = {}
#         if moduleName == "navigate":
#             skillSuccess = self._topicListener.localVarNamesAndValues["navigate"]["skillSuccess"]
#             goal_reached = self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]
#             print("skillSuccessValue is  = " + skillSuccess)
#             print("goal_ReachedValue is  = " + goal_reached)
#             nav_to_x = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_x"]
#             nav_to_y = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_y"]
#             nav_to_z = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_z"]
#             if DEBUG:
#                 print("navigate action local variables:")
#                 print("skillSuccess:", skillSuccess)
#                 print("goal_reached:", goal_reached)
#             if skillSuccess and goal_reached:
#                 moduleResponse = "navigate_eSuccess"
#             else:
#                 moduleResponse = "navigate_eFailed"

#         if DEBUG and not getHeavyLocalVarList(moduleName):
#             print("moduleResponse result:", moduleResponse)
#         moduleLocalVars = self._topicListener.localVarNamesAndValues.get(moduleName, {})
#         moduleResponseItem = {"Module": moduleName, "ActionSequenceId": actionSequenceID,
#                               "ModuleResponseText": moduleResponse, "StartTime": startTime, "EndTime": datetime.datetime.utcnow(),
#                               "ActionForExecutionId": self.current_action_for_execution_id,
#                               "LocalVariables": moduleLocalVars}

#         aos_ModuleResponses_collection.replace_one(filter1, moduleResponseItem, upsert=True)
#         for varName, value in assignGlobalVar.items():
#             isInit = value is not None
#             aos_GlobalVariablesAssignments_collection.replace_one({"GlobalVariableName": varName},
#                                                                   {"GlobalVariableName": varName, "LowLevelValue": value,
#                                                                    "IsInitialized": isInit, "UpdatingActionSequenceId": actionSequenceID,
#                                                                    "ModuleResponseId": moduleResponseItem["_id"]}, upsert=True)

#     def listen_to_mongodb_commands(self):
#       while(True):  
#         filter1 = {"ActionSequenceId": self.current_action_sequence_id}
#         registerLog("navigate start: with this id : "+ str(self.current_action_sequence_id))
#         actionForExecution = collActionForExecution.find_one(filter1)
#         if actionForExecution:
#             if DEBUG:
#                 print("~~~~~~~~")
#                 print("actionID:", actionForExecution["ActionID"])
#             moduleName = actionForExecution["ActionName"]
#             actionParameters = actionForExecution["Parameters"]
#             self.current_action_for_execution_id = actionForExecution["_id"]
#             self._topicListener.setListenTarget(moduleName)
#             time.sleep(0.3)
#             moduleActivationStart = datetime.datetime.utcnow()
#             responseNotByLocalVariables = None
#             print("module name:", moduleName)
#             registerLog("Request to call to module: " + moduleName)

#             if moduleName == "navigate":
#                 print("handle navigate")
#                 responseNotByLocalVariables = self.handle_navigate(actionParameters)

#             # Here we wait for the goal reached message
#             registerLog("navigate start:")
#             time.sleep(0.3)
#             self._topicListener.setListenTarget("after action")
#             # while not self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]:
#                 # print("helllllooooooooooooooooooooooooo")
#                 # rclpy.spin_once(self, timeout_sec=0.3)
#             self.registerModuleResponse(moduleName, moduleActivationStart, self.current_action_sequence_id,
#                                         responseNotByLocalVariables)
#             registerLog("navigate finished")
#             if DEBUG:
#                 print("111111111111111111111111111:" + str(self.current_action_sequence_id))
#             self.current_action_sequence_id += 1
#             if DEBUG:
#                 print("111111111111111111111111111:" + str(self.current_action_sequence_id))
#             self.current_action_for_execution_id=None
#             time.sleep(0.1)
    

# class AOS_TopicListenerServer(Node):
#     def __init__(self):
#         super().__init__('aos_topic_listener_server')
#         print("NAAAAAAAAAAAATAASHHHHHHKAa")
#         self.localVarNamesAndValues = {"navigate": {"skillSuccess": None, "goal_reached": False, "nav_to_x": None, "nav_to_y": None, "nav_to_z": None}}
#         self.setListenTarget("initTopicListener")
#         self.subscription = self.create_subscription(Log, '/rosout', self.cb__rosout, 10)
#         print("LOLO")
#         # print(type(self.cb_rosout))
#         self.get_logger().info("AOS_TopicListenerServer initialized and subscribed to /rosout")
        
#     def cb__rosout(self, msg):
#         print("NAtaaaaaaaaaaaashshshshshshshshsha")
#         try:
#             print("44444444444444444444444444444")
#             print(self.listenTargetModule)
#             if self.listenTargetModule == "navigate":
#                 # if DEBUG:
#                     # print("handling topic call:navigate")
#                     # print(msg)
#                 print("checkinggg valuesssssssssssssssssssss")    
#                 value = self.navigate_get_value_goal_succeeded(msg)
#                 print("this is the value of goalllll reached :"+ str(value))
#                 self.updateLocalVariableValue("goal_reached", value)

#         except Exception as e:
#             registerError(str(e), traceback.format_exc(), 'topic /rosout')

#     def navigate_get_value_goal_succeeded(self, __input):
#         if 'Sending response to client: True' in __input.msg:
#             print("checkinggg valuesssssssssssssssssssss2222222222222222222222222222222222222")    
#             registerLog("goalllllllll reacheddd")            
#             print("Goal succeeded detected in message")
#             TEMP=True
#             return True
#         return False

#     def initLocalVars(self, moduleNameToInit):
#         if DEBUG:
#             print("initLocalVars:")
#             print(moduleNameToInit)
#         for moduleName, localVarNamesAndValuesPerModule in self.localVarNamesAndValues.items():
#             for localVarName, value in localVarNamesAndValuesPerModule.items():
#                 if moduleName == moduleNameToInit:
#                     if DEBUG:
#                         print("init var:")
#                         print(localVarName)
#                     aos_local_var_collection.replace_one({"Module": moduleName, "VarName": localVarName},
#                                                          {"Module": moduleName, "VarName": localVarName, "Value": value},
#                                                          upsert=True)
#                     aosStats_local_var_collection.insert_one(
#                         {"Module": moduleName, "VarName": localVarName, "value": value, "Time": datetime.datetime.utcnow()})

#     def setListenTarget(self, _listenTargetModule):
#         registerLog("check the setlistentarget:")
#         self.initLocalVars(_listenTargetModule)
#         registerLog("check the initLocalVars:")

#         if DEBUG:
#             print('setListenTopicTargetModule:')
#             print(_listenTargetModule)
#         self.listenTargetModule = _listenTargetModule

#     def updateLocalVariableValue(self, varName, value):
#         if DEBUG and varName not in getHeavyLocalVarList(self.listenTargetModule):
#             print("update local var:")
#             print(varName)
#             print(value)
#         if self.listenTargetModule not in self.localVarNamesAndValues:
#             return
#         if self.localVarNamesAndValues[self.listenTargetModule][varName] != value:
#             if DEBUG:
#                 print("ACTUAL UPDATE --------------------------------------------------------------------------")
#             self.localVarNamesAndValues[self.listenTargetModule][varName] = value
#             if varName not in getHeavyLocalVarList(self.listenTargetModule):
#                 aos_local_var_collection.replace_one({"Module": self.listenTargetModule, "VarName": varName},
#                                                      {"Module": self.listenTargetModule, "VarName": varName, "Value": value}, upsert=True)
#                 aosStats_local_var_collection.insert_one(
#                     {"Module": self.listenTargetModule, "VarName": varName, "value": value, "Time": datetime.datetime.utcnow()})
#                 if DEBUG:
#                     print("WAS UPDATED --------------------------------------------------------------------------")

# def main(args=None):
#     rclpy.init(args=args)

#     topic_listener = AOS_TopicListenerServer()
#     command_listener = ListenToMongoDbCommands(topic_listener)

#     # Create MultiThreadedExecutor to manage multiple nodes
#     executor = MultiThreadedExecutor()
#     executor.add_node(topic_listener)
#     executor.add_node(command_listener)

#     topic_listener.get_logger().info("Nodes initialized and added to executor")

#     try:
#         executor.spin()
#     except KeyboardInterrupt:
#         pass
#     finally:
#         executor.shutdown()
#         topic_listener.destroy_node()
#         command_listener.destroy_node()
#         rclpy.shutdown()

# if __name__ == '__main__':
#     main()






# import datetime
# import rclpy
# import rclpy.executors
# from rclpy.node import Node
# from rclpy.action import ActionClient
# import pymongo
# import traceback
# from geometry_msgs.msg import Point
# from nav2_msgs.action import NavigateToPose
# from rcl_interfaces.msg import Log
# from interfaces_robot.srv import NavigateToCoordinates
# from rclpy.executors import MultiThreadedExecutor,SingleThreadedExecutor
# import time  # Import time module to add sleep

# DEBUG = True
# HEAVY_LOCAL_VARS = {}
# aosDbConnection = pymongo.MongoClient("mongodb://localhost:27017/")
# aosDB = aosDbConnection["AOS"]
# aos_statisticsDB = aosDbConnection["AOS_Statistics"]
# aos_local_var_collection = aosDB["LocalVariables"]
# aosStats_local_var_collection = aos_statisticsDB["LocalVariables"]
# aos_GlobalVariablesAssignments_collection = aosDB["GlobalVariablesAssignments"]
# aos_ModuleResponses_collection = aosDB["ModuleResponses"]
# collActionForExecution = aosDB["ActionsForExecution"]
# collLogs = aosDB["Logs"]
# collActions = aosDB["Actions"]

# def registerError(errorStr, trace, comments=None):
#     error = {
#         "Component": "RosMiddleware", "Event": errorStr, "Advanced": trace, "LogLevel": 2, "LogLevelDesc": "Error",
#         "Time": datetime.datetime.utcnow()
#     }
#     if comments is not None:
#         error = {
#             "Component": "RosMiddleware", "Error": errorStr, "Advanced": str(comments) + ". " + str(trace),
#             "Time": datetime.datetime.utcnow()
#         }
#     collLogs.insert_one(error)

# def registerLog(logStr):
#     log = {
#         "Component": "RosMiddleware", "Event": logStr, "LogLevel": 5, "LogLevelDesc": "Debug", "Advanced": "",
#         "Time": datetime.datetime.utcnow()
#     }
#     collLogs.insert_one(log)

# def getHeavyLocalVarList(moduleName):
#     return HEAVY_LOCAL_VARS.get(moduleName, [])
# class SharedState1:
#     def __init__(self):
#         self.goal_reached = False
# class ListenToMongoDbCommands(Node):
#     def __init__(self, topic_listener,shared_state):
#         super().__init__('listen_to_mongodb_commands')
#         self.current_action_sequence_id = 1
#         self.current_action_for_execution_id = None
#         self.navigate_service_name = "/navigate_to_coordinates"
#         self._topicListener = topic_listener
#         self.cli = self.create_client(NavigateToCoordinates, self.navigate_service_name)
#         self.shared_state = shared_state

        
#         while not self.cli.wait_for_service(timeout_sec=1.0):
#             self.get_logger().info('Service not available, waiting again...')

#         self.timer = self.create_timer(1.0, self.listen_to_mongodb_commands)

#     # def handle_navigate(self, params):
#     #     responseNotByLocalVariables = None
#     #     nav_to_x, nav_to_y, nav_to_z = "", "", ""
#     #     try:
#     #         nav_to_x = params["ParameterValues"]["x"]
#     #         self._topicListener.updateLocalVariableValue("nav_to_x", nav_to_x)
#     #         nav_to_y = params["ParameterValues"]["y"]
#     #         self._topicListener.updateLocalVariableValue("nav_to_y", nav_to_y)
#     #         nav_to_z = params["ParameterValues"]["z"]
#     #         self._topicListener.updateLocalVariableValue("nav_to_z", nav_to_z)
#     #     except Exception as e:
#     #         registerError(str(e), traceback.format_exc(), 'Action: navigate, illegalActionObs')
#     #         responseNotByLocalVariables = "illegalActionObs"
#     #         return responseNotByLocalVariables
    
#     #     try:
#     #         registerLog("wait for service: moduleName=navigate, serviceName=navigate")
#     #         req = NavigateToCoordinates.Request()
#     #         req.x = float(nav_to_x)
#     #         req.y = float(nav_to_y)
#     #         req.z = float(nav_to_z)
#     #         self.get_logger().info("Sending request to service, moduleName=navigate")
#     #         future = self.cli.call_async(req)
#     #         registerLog("Service call made, waiting for response")
#     #         rclpy.spin_until_future_complete(self,future)
#     #         # future.add_done_callback(self.navigate_callback)
#     #         registerLog("Callback added to future")
#     #     except Exception as e:
#     #         registerError(str(e), traceback.format_exc(), 'Action: navigate')
#     #         print("Service call failed")
    
#      #     return responseNotByLocalVariables
#     def handle_navigate(self, params):
#      responseNotByLocalVariables = None
#      nav_to_x, nav_to_y, nav_to_z = "", "", ""
#      try:
#          nav_to_x = params["ParameterValues"]["x"]
#          self._topicListener.updateLocalVariableValue("nav_to_x", nav_to_x)
#          nav_to_y = params["ParameterValues"]["y"]
#          self._topicListener.updateLocalVariableValue("nav_to_y", nav_to_y)
#          nav_to_z = params["ParameterValues"]["z"]
#          self._topicListener.updateLocalVariableValue("nav_to_z", nav_to_z)
#      except Exception as e:
#          registerError(str(e), traceback.format_exc(), 'Action: navigate, illegalActionObs')
#          responseNotByLocalVariables = "illegalActionObs"
#          return responseNotByLocalVariables
 
#      try:
#          registerLog("wait for service: moduleName=navigate, serviceName=navigate")
#          req = NavigateToCoordinates.Request()
#          req.x = float(nav_to_x)
#          req.y = float(nav_to_y)
#          req.z = float(nav_to_z)
#          self.get_logger().info("Sending request to service, moduleName=navigate")
#          future = self.cli.call_async(req)
#          registerLog("Service call made, waiting for response")
#          registerLog("Sself.shared_state.goal_reached" + str(self.shared_state.goal_reached))

#         #  while not self.shared_state.goal_reached:
#             # rclpy.spin_once(self)
#             # self.get_logger().info('Waiting for goal to be reached...')
#             # time.sleep(0.1)  # Add a small sleep to allow state updates
#         #  rclpy.spin_until_future_complete(self, future)
#          registerLog("Sself.shared_state.goal_reached2  " + str(self.shared_state.goal_reached))
#          future.add_done_callback(self.navigate_callback)   
#          registerLog("Callback added to future")
#          registerLog("Callback added to future" + str(result))
#         #  result = future.result()
#         #  registerLog("Future result obtained")
#         #  if result is not None:
#         #      self.get_logger().info("Service response received, moduleName=navigate")
#         #      skillSuccess = result.success
#         #      registerLog(f"Service response success: {skillSuccess}")
#         #      self._topicListener.updateLocalVariableValue("skillSuccess", skillSuccess)
#         #      if DEBUG:
#         #          print("navigate service terminated")
#         #  else:
#         #      self.get_logger().error("Service call failed, result is None")
#         #      registerLog("Service call failed, result is None")
#      except Exception as e:
#          registerError(str(e), traceback.format_exc(), 'Action: navigate')
#          print("Service call failed")
 
#      return responseNotByLocalVariables
 
    

#     def navigate_callback(self, future):
#         try:
#             registerLog("navigate_callback invoked")
#             result = future.result()
#             registerLog("Future result obtained")
#             if result is not None:
#                 self.get_logger().info("Service response received, moduleName=navigate")
#                 skillSuccess = result.success
#                 registerLog(f"Service response success: {skillSuccess}")
#                 self._topicListener.updateLocalVariableValue("skillSuccess", skillSuccess)
#                 if DEBUG:
#                     print("navigate service terminated")
#             else:
#                 self.get_logger().error("Service call failed, result is None")
#                 registerLog("Service call failed, result is None")
#         except Exception as e:
#             registerError(str(e), traceback.format_exc(), 'Action: navigate')
#             print("Service call failed")
    

#     def saveHeavyLocalVariableToDB(self, moduleName):
#         for varName in getHeavyLocalVarList(moduleName):
#             value = self._topicListener.localVarNamesAndValues[moduleName][varName]
#             aos_local_var_collection.replace_one({"Module": moduleName, "VarName": varName},
#                                                  {"Module": moduleName, "VarName": varName,
#                                                   "Value": value}, upsert=True)
#             aosStats_local_var_collection.insert_one(
#                 {"Module": moduleName, "VarName": varName, "value": value,
#                  "Time": datetime.datetime.utcnow()})

#     def registerModuleResponse(self, moduleName, startTime, actionSequenceID, responseNotByLocalVariables):
#         registerLog("in the function registerModuleResponse:::::::: ")
#         self._topicListener.initLocalVars(moduleName)  # Ensure initialization
#         registerLog("in the function registerModuleResponse222222222222:::::::: ")

#         self.saveHeavyLocalVariableToDB(moduleName)
#         registerLog("in the function registerModuleResponse333333333333333:::::::: ")

#         filter1 = {"ActionSequenceId": actionSequenceID}
#         # if DEBUG:
#             # print("registerModuleResponse()")

#         if responseNotByLocalVariables is not None:
#             moduleResponseItem = {"Module": moduleName, "ActionSequenceId": actionSequenceID,
#                                   "ModuleResponseText": responseNotByLocalVariables, "StartTime": startTime,
#                                   "EndTime": datetime.datetime.utcnow(),
#                                   "ActionForExecutionId": self.current_action_for_execution_id}
#             aos_ModuleResponses_collection.replace_one(filter1, moduleResponseItem, upsert=True)
#             return
#         registerLog("in the function registerModuleResponse444444444:::::::: ")

#         moduleResponse = ""
#         assignGlobalVar = {}
#         if moduleName == "navigate":
#             registerLog("in the function registerModuleResponse5555555555:::::::: ")
#             skillSuccess = self._topicListener.localVarNamesAndValues["navigate"]["skillSuccess"]
#             registerLog("skillSuccess:  "  +  str(skillSuccess))
#             registerLog("in the function registerModuleResponse66666666666666666:::::::: ")
#             goal_reached = self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]
#             # registerLog("skillSuccessValue is  = " + skillSuccess)
#             registerLog("goal_ReachedValue is  = " + str(goal_reached))
#             nav_to_x = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_x"]
#             nav_to_y = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_y"]
#             nav_to_z = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_z"]
#             # if DEBUG:
#             #     registerLog("navigate action local variables:")
#             #     registerLog("skillSuccess:  "  +  skillSuccess)
#             #     registerLog("goal_reached:  "  +  goal_reached)
#             if skillSuccess and goal_reached:
#                 moduleResponse = "navigate_eSuccess"
#             else:
#                 moduleResponse = "navigate_eFailed"
#         registerLog("this is the response of the navigation : "+moduleResponse)
#         # if DEBUG and not getHeavyLocalVarList(moduleName):
#             # print("moduleResponse result:", moduleResponse)
#         moduleLocalVars = self._topicListener.localVarNamesAndValues.get(moduleName, {})
#         moduleResponseItem = {"Module": moduleName, "ActionSequenceId": actionSequenceID,
#                               "ModuleResponseText": moduleResponse, "StartTime": startTime, "EndTime": datetime.datetime.utcnow(),
#                               "ActionForExecutionId": self.current_action_for_execution_id,
#                               "LocalVariables": moduleLocalVars}

#         aos_ModuleResponses_collection.replace_one(filter1, moduleResponseItem, upsert=True)
#         for varName, value in assignGlobalVar.items():
#             isInit = value is not None
#             aos_GlobalVariablesAssignments_collection.replace_one({"GlobalVariableName": varName},
#                                                                   {"GlobalVariableName": varName, "LowLevelValue": value,
#                                                                    "IsInitialized": isInit, "UpdatingActionSequenceId": actionSequenceID,
#                                                                    "ModuleResponseId": moduleResponseItem["_id"]}, upsert=True)

#     def listen_to_mongodb_commands(self):
#         filter1 = {"ActionSequenceId": self.current_action_sequence_id}
#         actionForExecution = collActionForExecution.find_one(filter1)
#         if actionForExecution:
#             if DEBUG:
#                 print("~~~~~~~~")
#                 print("actionID:", actionForExecution["ActionID"])
#             moduleName = actionForExecution["ActionName"]
#             actionParameters = actionForExecution["Parameters"]
#             self.current_action_for_execution_id = actionForExecution["_id"]
#             registerLog("navigate start with id :::" + str(self.current_action_sequence_id))
#             self._topicListener.setListenTarget(moduleName)
#             moduleActivationStart = datetime.datetime.utcnow()
#             responseNotByLocalVariables = None
#             print("module name:", moduleName)
#             registerLog("Request to call to module: " + moduleName)
#             registerLog("navigate start:")
#             if moduleName == "navigate":
#                 print("handle navigate")
#                 responseNotByLocalVariables = self.handle_navigate(actionParameters)
#             registerLog("navigate finished:")
#             while not self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]:
#                 rclpy.spin_once(self, timeout_sec=0.3)
#             registerLog("after while loop of goal reached")    
#             self.registerModuleResponse(moduleName, moduleActivationStart, self.current_action_sequence_id,
#                                         responseNotByLocalVariables)
#             if DEBUG:
#                 print("navigate finished")
#             self.current_action_sequence_id += 1

# class AOS_TopicListenerServer(Node):
#     def __init__(self,shared_state):
#         super().__init__('aos_topic_listener_server')
#         print("NAAAAAAAAAAAATAASHHHHHHKAa")
#         self.localVarNamesAndValues = {"navigate": {"skillSuccess": None, "goal_reached": False, "nav_to_x": None, "nav_to_y": None, "nav_to_z": None}}
#         self.setListenTarget("initTopicListener")
#         self.subscription = self.create_subscription(Log, '/rosout', self.cb__rosout, 10)
#         print("LOLO")
#         self.shared_state = shared_state
#         self.get_logger().info("AOS_TopicListenerServer initialized and subscribed to /rosout")
        
#     def cb__rosout(self, msg):
#         print("NAtaaaaaaaaaaaashshshshshshshshsha")
#         try:
#             print("44444444444444444444444444444")
#             print(self.listenTargetModule)
#             if self.listenTargetModule == "navigate":
#                 if DEBUG:
#                     print("handling topic call:navigate")
#                     print(msg)
#                 print("checkinggg valuesssssssssssssssssssss")    
#                 value = self.navigate_get_value_goal_succeeded(msg)
#                 print("this is the value of goalllll reached :"+ str(value))
#                 self.updateLocalVariableValue("goal_reached", value)

#         except Exception as e:
#             registerError(str(e), traceback.format_exc(), 'topic /rosout')

#     def navigate_get_value_goal_succeeded(self, __input):
#         if 'Goal succeeded' in __input.msg:
#             self.shared_state.goal_reached = True
#             print("checkinggg valuesssssssssssssssssssss2222222222222222222222222222222222222")    
#             registerLog("goalllllllll reacheddd")            
#             print("Goal succeeded detected in message")
#             return True
#         return False

#     def initLocalVars(self, moduleNameToInit):
#         # if DEBUG:
#             # print("initLocalVars:")
#             # print(moduleNameToInit)
#         for moduleName, localVarNamesAndValuesPerModule in self.localVarNamesAndValues.items():
#             for localVarName, value in localVarNamesAndValuesPerModule.items():
#                 if moduleName == moduleNameToInit:
#                     # if DEBUG:
#                         # print("init var:")
#                         # print(localVarName)
#                     aos_local_var_collection.replace_one({"Module": moduleName, "VarName": localVarName},
#                                                          {"Module": moduleName, "VarName": localVarName, "Value": value},
#                                                          upsert=True)
#                     aosStats_local_var_collection.insert_one(
#                         {"Module": moduleName, "VarName": localVarName, "value": value, "Time": datetime.datetime.utcnow()})

#     def setListenTarget(self, _listenTargetModule):
#         self.initLocalVars(_listenTargetModule)
#         if DEBUG:
#             print('setListenTopicTargetModule:')
#             print(_listenTargetModule)
#         self.listenTargetModule = _listenTargetModule

#     def updateLocalVariableValue(self, varName, value):
#         if DEBUG and varName not in getHeavyLocalVarList(self.listenTargetModule):
#             print("update local var:")
#             print(varName)
#             print(value)
#         if self.listenTargetModule not in self.localVarNamesAndValues:
#             return
#         if self.localVarNamesAndValues[self.listenTargetModule][varName] != value:
#             if DEBUG:
#                 print("ACTUAL UPDATE --------------------------------------------------------------------------")
#             self.localVarNamesAndValues[self.listenTargetModule][varName] = value
#             if varName not in getHeavyLocalVarList(self.listenTargetModule):
#                 aos_local_var_collection.replace_one({"Module": self.listenTargetModule, "VarName": varName},
#                                                      {"Module": self.listenTargetModule, "VarName": varName, "Value": value}, upsert=True)
#                 aosStats_local_var_collection.insert_one(
#                     {"Module": self.listenTargetModule, "VarName": varName, "value": value, "Time": datetime.datetime.utcnow()})
#                 if DEBUG:
#                     print("WAS UPDATED --------------------------------------------------------------------------")

# def main(args=None):
#     try:
#         rclpy.init(args=args)
#         shared_state = SharedState1()
#         topic_listener = AOS_TopicListenerServer(shared_state)
#         command_listener = ListenToMongoDbCommands(topic_listener, shared_state)

#         executor = rclpy.executors.SingleThreadedExecutor()
#         executor.add_node(topic_listener)
#         executor.add_node(command_listener)

#         topic_listener.get_logger().info("Nodes initialized and added to executor")

#         executor.spin()
#     except KeyboardInterrupt:
#         pass
#     except Exception as e:
#         print(f"An error occurred: {e}")
#         registerError(str(e), traceback.format_exc(), 'main function')
#     finally:
#         executor.shutdown()
#         topic_listener.destroy_node()
#         command_listener.destroy_node()
#         rclpy.shutdown()

# if __name__ == '__main__':
#     main()

# import datetime
# import rclpy
# from rclpy.node import Node
# from rclpy.action import ActionClient
# import pymongo
# import traceback
# from geometry_msgs.msg import Point
# from nav2_msgs.action import NavigateToPose
# from rcl_interfaces.msg import Log
# from interfaces_robot.srv import NavigateToCoordinates
# from rclpy.executors import MultiThreadedExecutor
# import time
# from functools import partial

# DEBUG = True
# HEAVY_LOCAL_VARS = {}
# aosDbConnection = pymongo.MongoClient("mongodb://localhost:27017/")
# aosDB = aosDbConnection["AOS"]
# aos_statisticsDB = aosDbConnection["AOS_Statistics"]
# aos_local_var_collection = aosDB["LocalVariables"]
# aosStats_local_var_collection = aos_statisticsDB["LocalVariables"]
# aos_GlobalVariablesAssignments_collection = aosDB["GlobalVariablesAssignments"]
# aos_ModuleResponses_collection = aosDB["ModuleResponses"]
# collActionForExecution = aosDB["ActionsForExecution"]
# collLogs = aosDB["Logs"]
# collActions = aosDB["Actions"]

# def registerError(errorStr, trace, comments=None):
#     error = {
#         "Component": "RosMiddleware", "Event": errorStr, "Advanced": trace, "LogLevel": 2, "LogLevelDesc": "Error",
#         "Time": datetime.datetime.utcnow()
#     }
#     if comments is not None:
#         error = {
#             "Component": "RosMiddleware", "Error": errorStr, "Advanced": str(comments) + ". " + str(trace),
#             "Time": datetime.datetime.utcnow()
#         }
#     collLogs.insert_one(error)

# def registerLog(logStr):
#     log = {
#         "Component": "RosMiddleware", "Event": logStr, "LogLevel": 5, "LogLevelDesc": "Debug", "Advanced": "",
#         "Time": datetime.datetime.utcnow()
#     }
#     collLogs.insert_one(log)

# def getHeavyLocalVarList(moduleName):
#     return HEAVY_LOCAL_VARS.get(moduleName, [])

# class ListenToMongoDbCommands(Node):
#     def __init__(self, topic_listener):
#         super().__init__('listen_to_mongodb_commands')
#         self.current_action_sequence_id = 1
#         self.current_action_for_execution_id = None
#         self.navigate_service_name = "/navigate_to_coordinates"
#         self._topicListener = topic_listener
#         self.cli = self.create_client(NavigateToCoordinates, self.navigate_service_name)
        
#         while not self.cli.wait_for_service(timeout_sec=1.0):
#             self.get_logger().info('Service not available, waiting again...')

#         self.timer = self.create_timer(1.0, self.listen_to_mongodb_commands)

#     def handle_navigate(self, params):
#         responseNotByLocalVariables = None
#         nav_to_x, nav_to_y, nav_to_z = "", "", ""
#         try:
#             nav_to_x = params["ParameterValues"]["x"]
#             self._topicListener.updateLocalVariableValue("nav_to_x", nav_to_x)
#             nav_to_y = params["ParameterValues"]["y"]
#             self._topicListener.updateLocalVariableValue("nav_to_y", nav_to_y)
#             nav_to_z = params["ParameterValues"]["z"]
#             self._topicListener.updateLocalVariableValue("nav_to_z", nav_to_z)
#         except Exception as e:
#             registerError(str(e), traceback.format_exc(), 'Action: navigate, illegalActionObs')
#             responseNotByLocalVariables = "illegalActionObs"
#             return responseNotByLocalVariables
    
#         try:
#             registerLog("wait for service: moduleName=navigate, serviceName=navigate")
            
#             # self.cli = self.create_client(NavigateToCoordinates, self.navigate_service_name)    
#             # while not self.cli.wait_for_service(timeout_sec=1.0):
#             #    self.get_logger().info('Service not available, waiting again...')
#             req = NavigateToCoordinates.Request()
#             req.x = float(nav_to_x)
#             req.y = float(nav_to_y)
#             req.z = float(nav_to_z)
#             self.get_logger().info("Sending request to service, moduleName=navigate")
#             future = self.cli.call_async(req)
#             registerLog("Service call made, waiting for response")
#             future.add_done_callback(partial(self.navigate_callback,x=float(nav_to_x),y=float(nav_to_y),z=float(nav_to_z)))
#             # future.
#             registerLog("Callback added to future")
#         except Exception as e:
#             registerError(str(e), traceback.format_exc(), 'Action: navigate')
#             print("Service call failed")
    
#         return responseNotByLocalVariables
    

#     def navigate_callback(self, future,x,y,z):
#         try:
#             registerLog("navigate_callback invoked")
#             result = future.result()
#             registerLog("Future result obtained")
#             if result is not None:
#                 self.get_logger().info("Service response received, moduleName=navigate")
#                 skillSuccess = result.success
#                 registerLog(f"Service response success: {skillSuccess}")
#                 self._topicListener.updateLocalVariableValue("skillSuccess", skillSuccess)
#                 if DEBUG:
#                     print("navigate service terminated")
#             else:
#                 self.get_logger().error("Service call failed, result is None")
#                 registerLog("Service call failed, result is None")
#         except Exception as e:
#             registerError(str(e), traceback.format_exc(), 'Action: navigate')
#             print("Service call failed")
    

#     def saveHeavyLocalVariableToDB(self, moduleName):
#         for varName in getHeavyLocalVarList(moduleName):
#             value = self._topicListener.localVarNamesAndValues[moduleName][varName]
#             aos_local_var_collection.replace_one({"Module": moduleName, "VarName": varName},
#                                                  {"Module": moduleName, "VarName": varName,
#                                                   "Value": value}, upsert=True)
#             aosStats_local_var_collection.insert_one(
#                 {"Module": moduleName, "VarName": varName, "value": value,
#                  "Time": datetime.datetime.utcnow()})

#     def registerModuleResponse(self, moduleName, startTime, actionSequenceID, responseNotByLocalVariables):
#         registerLog("in the function registerModuleResponse:::::::: ")
#         self._topicListener.initLocalVars(moduleName)  # Ensure initialization
#         registerLog("in the function registerModuleResponse222222222222:::::::: ")

#         self.saveHeavyLocalVariableToDB(moduleName)
#         registerLog("in the function registerModuleResponse333333333333333:::::::: ")

#         filter1 = {"ActionSequenceId": actionSequenceID}
#         # if DEBUG:
#             # print("registerModuleResponse()")

#         if responseNotByLocalVariables is not None:
#             moduleResponseItem = {"Module": moduleName, "ActionSequenceId": actionSequenceID,
#                                   "ModuleResponseText": responseNotByLocalVariables, "StartTime": startTime,
#                                   "EndTime": datetime.datetime.utcnow(),
#                                   "ActionForExecutionId": self.current_action_for_execution_id}
#             aos_ModuleResponses_collection.replace_one(filter1, moduleResponseItem, upsert=True)
#             return
#         registerLog("in the function registerModuleResponse444444444:::::::: ")

#         moduleResponse = ""
#         assignGlobalVar = {}
#         if moduleName == "navigate":
#             registerLog("in the function registerModuleResponse5555555555:::::::: ")
#             skillSuccess = self._topicListener.localVarNamesAndValues["navigate"]["skillSuccess"]
#             registerLog("skillSuccess:  "  +  str(skillSuccess))
#             registerLog("in the function registerModuleResponse66666666666666666:::::::: ")
#             goal_reached = self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]
#             # registerLog("skillSuccessValue is  = " + skillSuccess)
#             registerLog("goal_ReachedValue is  = " + str(goal_reached))
#             nav_to_x = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_x"]
#             nav_to_y = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_y"]
#             nav_to_z = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_z"]
#             # if DEBUG:
#             #     registerLog("navigate action local variables:")
#             #     registerLog("skillSuccess:  "  +  skillSuccess)
#             #     registerLog("goal_reached:  "  +  goal_reached)
#             if skillSuccess and goal_reached:
#                 moduleResponse = "navigate_eSuccess"
#             else:
#                 moduleResponse = "navigate_eFailed"
#         registerLog("this is the response of the navigation : "+moduleResponse)
#         # if DEBUG and not getHeavyLocalVarList(moduleName):
#             # print("moduleResponse result:", moduleResponse)
#         moduleLocalVars = self._topicListener.localVarNamesAndValues.get(moduleName, {})
#         moduleResponseItem = {"Module": moduleName, "ActionSequenceId": actionSequenceID,
#                               "ModuleResponseText": moduleResponse, "StartTime": startTime, "EndTime": datetime.datetime.utcnow(),
#                               "ActionForExecutionId": self.current_action_for_execution_id,
#                               "LocalVariables": moduleLocalVars}

#         aos_ModuleResponses_collection.replace_one(filter1, moduleResponseItem, upsert=True)
#         for varName, value in assignGlobalVar.items():
#             isInit = value is not None
#             aos_GlobalVariablesAssignments_collection.replace_one({"GlobalVariableName": varName},
#                                                                   {"GlobalVariableName": varName, "LowLevelValue": value,
#                                                                    "IsInitialized": isInit, "UpdatingActionSequenceId": actionSequenceID,
#                                                                    "ModuleResponseId": moduleResponseItem["_id"]}, upsert=True)

#     def listen_to_mongodb_commands(self):
#        while(True): 
#         filter1 = {"ActionSequenceId": self.current_action_sequence_id}
#         actionForExecution = collActionForExecution.find_one(filter1)
#         if actionForExecution:
#             if DEBUG:
#                 print("~~~~~~~~")
#                 print("actionID:", actionForExecution["ActionID"])
#             moduleName = actionForExecution["ActionName"]
#             actionParameters = actionForExecution["Parameters"]
#             self.current_action_for_execution_id = actionForExecution["_id"]
#             time.sleep(0.3)
#             registerLog("navigate start with id :::" + str(self.current_action_sequence_id))
#             self._topicListener.setListenTarget(moduleName)
#             moduleActivationStart = datetime.datetime.utcnow()
#             responseNotByLocalVariables = None
#             print("module name:", moduleName)
#             registerLog("Request to call to module: " + moduleName)
#             registerLog("navigate start:")
#             if moduleName == "navigate":
#                 print("handle navigate")
#                 responseNotByLocalVariables = self.handle_navigate(actionParameters)
#             time.sleep(0.3)   
#             self._topicListener.setListenTarget("after action")
#             registerLog("navigate finished:")
#             ###we have to check this line
#             registerLog("localVarNamesAndValues[navigate][goal_reached] : "  + str(self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]))

#             while not self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]:
#                 rclpy.spin_once(self, timeout_sec=0.3)
#             registerLog("after while loop of goal reached")    
#             self.registerModuleResponse(moduleName, moduleActivationStart, self.current_action_sequence_id,
#                                         responseNotByLocalVariables)
#             if DEBUG:
#                 print("navigate finished")
#             self.current_action_sequence_id += 1
#             self.currentActionFotExecutionId = None
#             time.sleep(0.1)   



# class AOS_TopicListenerServer(Node):
#     def __init__(self):
#         super().__init__('aos_topic_listener_server')
#         print("NAAAAAAAAAAAATAASHHHHHHKAa")
#         self.localVarNamesAndValues = {"navigate": {"skillSuccess": None, "goal_reached": False, "nav_to_x": None, "nav_to_y": None, "nav_to_z": None}}
#         self.setListenTarget("initTopicListener")
#         self.subscription = self.create_subscription(Log, '/rosout', self.cb__rosout, 10)
#         print("LOLO")
#         self.get_logger().info("AOS_TopicListenerServer initialized and subscribed to /rosout")
        
#     def cb__rosout(self, msg):
#         print("NAtaaaaaaaaaaaashshshshshshshshsha")
#         try:
#             # print("44444444444444444444444444444")
#             # print(self.listenTargetModule)
#             if self.listenTargetModule == "navigate":
#                 if DEBUG:
#                     print("handling topic call:navigate")
#                     print(msg)
#                 print("checkinggg valuesssssssssssssssssssss")    
#                 value = self.navigate_get_value_goal_succeeded(msg)
#                 print("this is the value of goalllll reached :"+ str(value))
#                 self.updateLocalVariableValue("goal_reached", value)

#         except Exception as e:
#             registerError(str(e), traceback.format_exc(), 'topic /rosout')

#     def navigate_get_value_goal_succeeded(self, __input):
#         if 'Goal has been reached.' in __input.msg:
#             print("checkinggg valuesssssssssssssssssssss2222222222222222222222222222222222222")    
#             registerLog("goalllllllll reacheddd")            
#             print("Goal succeeded detected in message")
#             return True
#         return False

#     def initLocalVars(self, moduleNameToInit):
#         # if DEBUG:
#             # print("initLocalVars:")
#             # print(moduleNameToInit)
#         for moduleName, localVarNamesAndValuesPerModule in self.localVarNamesAndValues.items():
#             for localVarName, value in localVarNamesAndValuesPerModule.items():
#                 if moduleName == moduleNameToInit:
#                     # if DEBUG:
#                         # print("init var:")
#                         # print(localVarName)
#                     aos_local_var_collection.replace_one({"Module": moduleName, "VarName": localVarName},
#                                                          {"Module": moduleName, "VarName": localVarName, "Value": value},
#                                                          upsert=True)
#                     aosStats_local_var_collection.insert_one(
#                         {"Module": moduleName, "VarName": localVarName, "value": value, "Time": datetime.datetime.utcnow()})

#     def setListenTarget(self, _listenTargetModule):
#         self.initLocalVars(_listenTargetModule)
#         if DEBUG:
#             print('setListenTopicTargetModule:')
#             print(_listenTargetModule)
#         self.listenTargetModule = _listenTargetModule

#     def updateLocalVariableValue(self, varName, value):
#         if DEBUG and varName not in getHeavyLocalVarList(self.listenTargetModule):
#             print("update local var:")
#             print(varName)
#             print(value)
#         if self.listenTargetModule not in self.localVarNamesAndValues:
#             return
#         if self.localVarNamesAndValues[self.listenTargetModule][varName] != value:
#             if DEBUG:
#                 print("ACTUAL UPDATE --------------------------------------------------------------------------")
#             self.localVarNamesAndValues[self.listenTargetModule][varName] = value
#             if varName not in getHeavyLocalVarList(self.listenTargetModule):
#                 aos_local_var_collection.replace_one({"Module": self.listenTargetModule, "VarName": varName},
#                                                      {"Module": self.listenTargetModule, "VarName": varName, "Value": value}, upsert=True)
#                 aosStats_local_var_collection.insert_one(
#                     {"Module": self.listenTargetModule, "VarName": varName, "value": value, "Time": datetime.datetime.utcnow()})
#                 if DEBUG:
#                     print("WAS UPDATED --------------------------------------------------------------------------")

# def main(args=None):
#     rclpy.init(args=args)

#     topic_listener = AOS_TopicListenerServer()
#     command_listener = ListenToMongoDbCommands(topic_listener)

#     # Create MultiThreadedExecutor to manage multiple nodes
#     executor = MultiThreadedExecutor()
#     executor.add_node(topic_listener)
#     executor.add_node(command_listener)

#     topic_listener.get_logger().info("Nodes initialized and added to executor")

#     try:
#         executor.spin()
#     except KeyboardInterrupt:
#         pass
#     finally:
#         executor.shutdown()
#         topic_listener.destroy_node()
#         command_listener.destroy_node()
#         rclpy.shutdown()

# if __name__ == '__main__':
#     main()


# import datetime
# import rclpy
# from rclpy.node import Node
# from rclpy.action import ActionClient
# import pymongo
# import traceback
# from geometry_msgs.msg import Point
# from nav2_msgs.action import NavigateToPose
# from rcl_interfaces.msg import Log
# from interfaces_robot.srv import NavigateToCoordinates
# from rclpy.executors import MultiThreadedExecutor
# import time

# DEBUG = True
# HEAVY_LOCAL_VARS = {}
# aosDbConnection = pymongo.MongoClient("mongodb://localhost:27017/")
# aosDB = aosDbConnection["AOS"]
# aos_statisticsDB = aosDbConnection["AOS_Statistics"]
# aos_local_var_collection = aosDB["LocalVariables"]
# aosStats_local_var_collection = aos_statisticsDB["LocalVariables"]
# aos_GlobalVariablesAssignments_collection = aosDB["GlobalVariablesAssignments"]
# aos_ModuleResponses_collection = aosDB["ModuleResponses"]
# collActionForExecution = aosDB["ActionsForExecution"]
# collLogs = aosDB["Logs"]
# collActions = aosDB["Actions"]

# def registerError(errorStr, trace, comments=None):
#     error = {
#         "Component": "RosMiddleware", "Event": errorStr, "Advanced": trace, "LogLevel": 2, "LogLevelDesc": "Error",
#         "Time": datetime.datetime.utcnow()
#     }
#     if comments is not None:
#         error = {
#             "Component": "RosMiddleware", "Error": errorStr, "Advanced": str(comments) + ". " + str(trace),
#             "Time": datetime.datetime.utcnow()
#         }
#     collLogs.insert_one(error)

# def registerLog(logStr):
#     log = {
#         "Component": "RosMiddleware", "Event": logStr, "LogLevel": 5, "LogLevelDesc": "Debug", "Advanced": "",
#         "Time": datetime.datetime.utcnow()
#     }
#     collLogs.insert_one(log)

# def getHeavyLocalVarList(moduleName):
#     return HEAVY_LOCAL_VARS.get(moduleName, [])

# class ListenToMongoDbCommands(Node):
#     def __init__(self, topic_listener,shared_state):
#         super().__init__('listen_to_mongodb_commands')
#         self.current_action_sequence_id = 1
#         self.current_action_for_execution_id = None
#         self.shared_state = shared_state
#         self.navigate_service_name = "/navigate_to_coordinates"
#         self._topicListener = topic_listener
#         self.cli = self.create_client(NavigateToCoordinates, self.navigate_service_name)
        
#         while not self.cli.wait_for_service(timeout_sec=1.0):
#             self.get_logger().info('Service not available, waiting again...')

#         self.timer = self.create_timer(1.0, self.listen_to_mongodb_commands)

#     def handle_navigate(self, params):
#         responseNotByLocalVariables = None
#         nav_to_x, nav_to_y, nav_to_z = "", "", ""
#         try:
#             nav_to_x = params["ParameterValues"]["x"]
#             self._topicListener.updateLocalVariableValue("nav_to_x", nav_to_x)
#             nav_to_y = params["ParameterValues"]["y"]
#             self._topicListener.updateLocalVariableValue("nav_to_y", nav_to_y)
#             nav_to_z = params["ParameterValues"]["z"]
#             self._topicListener.updateLocalVariableValue("nav_to_z", nav_to_z)
#         except Exception as e:
#             registerError(str(e), traceback.format_exc(), 'Action: navigate, illegalActionObs')
#             responseNotByLocalVariables = "illegalActionObs"
#             return responseNotByLocalVariables
    
#         try:
#             registerLog("wait for service: moduleName=navigate, serviceName=navigate")
#             req = NavigateToCoordinates.Request()
#             req.x = float(nav_to_x)
#             req.y = float(nav_to_y)
#             req.z = float(nav_to_z)
#             self.get_logger().info("Sending request to service, moduleName=navigate")
#             future = self.cli.call_async(req)
#             while not self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]:
#                           rclpy.spin_once(self._topicListener, timeout_sec=0.1)
#             registerLog("Service call made, waiting for response" + str(self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]))
#             future.add_done_callback(self.navigate_callback)
#             registerLog("Callback added to future")
#         except Exception as e:
#             registerError(str(e), traceback.format_exc(), 'Action: navigate')
#             print("Service call failed")
    
#         return responseNotByLocalVariables
    

#     def navigate_callback(self, future):
#         try:
#             registerLog("navigate_callback invoked")
#             result = future.result()
#             registerLog("Future result obtained")
#             if result is not None:
#                 self.get_logger().info("Service response received, moduleName=navigate")
#                 skillSuccess = result.success
#                 registerLog(f"Service response success: {skillSuccess}")
#                 self._topicListener.updateLocalVariableValue("skillSuccess", skillSuccess)
#                 if DEBUG:
#                     print("navigate service terminated")
#             else:
#                 self.get_logger().error("Service call failed, result is None")
#                 registerLog("Service call failed, result is None")
#         except Exception as e:
#             registerError(str(e), traceback.format_exc(), 'Action: navigate')
#             print("Service call failed")
    

#     def saveHeavyLocalVariableToDB(self, moduleName):
#         for varName in getHeavyLocalVarList(moduleName):
#             value = self._topicListener.localVarNamesAndValues[moduleName][varName]
#             aos_local_var_collection.replace_one({"Module": moduleName, "VarName": varName},
#                                                  {"Module": moduleName, "VarName": varName,
#                                                   "Value": value}, upsert=True)
#             aosStats_local_var_collection.insert_one(
#                 {"Module": moduleName, "VarName": varName, "value": value,
#                  "Time": datetime.datetime.utcnow()})

#     def registerModuleResponse(self, moduleName, startTime, actionSequenceID, responseNotByLocalVariables):
#         registerLog("in the function registerModuleResponse:::::::: ")
#         self._topicListener.initLocalVars(moduleName)  # Ensure initialization
#         registerLog("in the function registerModuleResponse222222222222:::::::: ")

#         self.saveHeavyLocalVariableToDB(moduleName)
#         registerLog("in the function registerModuleResponse333333333333333:::::::: ")

#         filter1 = {"ActionSequenceId": actionSequenceID}
#         # if DEBUG:
#             # print("registerModuleResponse()")

#         if responseNotByLocalVariables is not None:
#             moduleResponseItem = {"Module": moduleName, "ActionSequenceId": actionSequenceID,
#                                   "ModuleResponseText": responseNotByLocalVariables, "StartTime": startTime,
#                                   "EndTime": datetime.datetime.utcnow(),
#                                   "ActionForExecutionId": self.current_action_for_execution_id}
#             aos_ModuleResponses_collection.replace_one(filter1, moduleResponseItem, upsert=True)
#             return
#         registerLog("in the function registerModuleResponse444444444:::::::: ")

#         moduleResponse = ""
#         assignGlobalVar = {}
#         if moduleName == "navigate":
#             registerLog("in the function registerModuleResponse5555555555:::::::: ")
#             skillSuccess = self._topicListener.localVarNamesAndValues["navigate"]["skillSuccess"]
#             registerLog("skillSuccess:  "  +  str(skillSuccess))
#             registerLog("in the function registerModuleResponse66666666666666666:::::::: ")
#             goal_reached = self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]
#             # registerLog("skillSuccessValue is  = " + skillSuccess)
#             registerLog("goal_ReachedValue is  = " + str(goal_reached))
#             nav_to_x = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_x"]
#             nav_to_y = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_y"]
#             nav_to_z = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_z"]
#             # if DEBUG:
#             #     registerLog("navigate action local variables:")
#             #     registerLog("skillSuccess:  "  +  skillSuccess)
#             #     registerLog("goal_reached:  "  +  goal_reached)
#             if skillSuccess and goal_reached:
#                 moduleResponse = "navigate_eSuccess"
#             else:
#                 moduleResponse = "navigate_eFailed"
#         registerLog("this is the response of the navigation : "+moduleResponse)
#         # if DEBUG and not getHeavyLocalVarList(moduleName):
#             # print("moduleResponse result:", moduleResponse)
#         moduleLocalVars = self._topicListener.localVarNamesAndValues.get(moduleName, {})
#         moduleResponseItem = {"Module": moduleName, "ActionSequenceId": actionSequenceID,
#                               "ModuleResponseText": moduleResponse, "StartTime": startTime, "EndTime": datetime.datetime.utcnow(),
#                               "ActionForExecutionId": self.current_action_for_execution_id,
#                               "LocalVariables": moduleLocalVars}

#         aos_ModuleResponses_collection.replace_one(filter1, moduleResponseItem, upsert=True)
#         for varName, value in assignGlobalVar.items():
#             isInit = value is not None
#             aos_GlobalVariablesAssignments_collection.replace_one({"GlobalVariableName": varName},
#                                                                   {"GlobalVariableName": varName, "LowLevelValue": value,
#                                                                    "IsInitialized": isInit, "UpdatingActionSequenceId": actionSequenceID,
#                                                                    "ModuleResponseId": moduleResponseItem["_id"]}, upsert=True)

#     def listen_to_mongodb_commands(self):
#         filter1 = {"ActionSequenceId": self.current_action_sequence_id}
#         actionForExecution = collActionForExecution.find_one(filter1)
#         if actionForExecution:
#             if DEBUG:
#                 print("~~~~")
#                 print("actionID:", actionForExecution["ActionID"])
#             moduleName = actionForExecution["ActionName"]
#             actionParameters = actionForExecution["Parameters"]
#             self.current_action_for_execution_id = actionForExecution["_id"]
#             registerLog("navigate start with id :::" + str(self.current_action_sequence_id))
#             self._topicListener.setListenTarget(moduleName)
#             moduleActivationStart = datetime.datetime.utcnow()
#             responseNotByLocalVariables = None
#             print("module name:", moduleName)
#             registerLog("Request to call to module: " + moduleName)
#             registerLog("navigate start:")
#             if moduleName == "navigate":
#                 print("handle navigate")
#                 responseNotByLocalVariables = self.handle_navigate(actionParameters)
#             registerLog("navigate finished:")
#             # while not self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]:
#             #               rclpy.spin_once(self._topicListener, timeout_sec=0.1)
 
#             registerLog("after while loop of goal reached"+ str(self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]))    
#             self.registerModuleResponse(moduleName, moduleActivationStart, self.current_action_sequence_id,
#                                         responseNotByLocalVariables)
#             if DEBUG:
#                 print("navigate finished")
#             self.current_action_sequence_id += 1

# class AOS_TopicListenerServer(Node):
#     def __init__(self,shared_state):
#         super().__init__('aos_topic_listener_server')
#         print("NAAAAAAAAAAAATAASHHHHHHKAa")
#         self.shared_state = shared_state
#         self.localVarNamesAndValues = {"navigate": {"skillSuccess": None, "goal_reached": False, "nav_to_x": None, "nav_to_y": None, "nav_to_z": None}}
#         self.setListenTarget("initTopicListener")
#         self.subscription = self.create_subscription(Log, '/rosout', self.cb__rosout, 10)
#         print("LOLO")
#         self.get_logger().info("AOS_TopicListenerServer initialized and subscribed to /rosout")
        
#     def cb__rosout(self, msg):
#         print("NAtaaaaaaaaaaaashshshshshshshshsha")
#         try:
#             print("44444444444444444444444444444")
#             print(self.listenTargetModule)
#             if self.listenTargetModule == "navigate":
#                 if DEBUG:
#                     print("handling topic call:navigate")
#                     print(msg)
#                 print("checkinggg valuesssssssssssssssssssss")    
#                 value = self.navigate_get_value_goal_succeeded(msg)
#                 print("this is the value of goalllll reached :"+ str(value))
#                 self.updateLocalVariableValue("goal_reached", value)

#         except Exception as e:
#             registerError(str(e), traceback.format_exc(), 'topic /rosout')

#     def navigate_get_value_goal_succeeded(self, __input):
#         if 'Goal has been reached.' in __input.msg:
#             # print("checkinggg valuesssssssssssssssssssss2222222222222222222222222222222222222")    
#             # registerLog("goalllllllll reacheddd")            
#             # print("Goal succeeded detected in message")
#             self.shared_state.goal_reached = True
#             return True
#         return False

#     def initLocalVars(self, moduleNameToInit):
#         # if DEBUG:
#             # print("initLocalVars:")
#             # print(moduleNameToInit)
#         for moduleName, localVarNamesAndValuesPerModule in self.localVarNamesAndValues.items():
#             for localVarName, value in localVarNamesAndValuesPerModule.items():
#                 if moduleName == moduleNameToInit:
#                     # if DEBUG:
#                         # print("init var:")
#                         # print(localVarName)
#                     aos_local_var_collection.replace_one({"Module": moduleName, "VarName": localVarName},
#                                                          {"Module": moduleName, "VarName": localVarName, "Value": value},
#                                                          upsert=True)
#                     aosStats_local_var_collection.insert_one(
#                         {"Module": moduleName, "VarName": localVarName, "value": value, "Time": datetime.datetime.utcnow()})

#     def setListenTarget(self, _listenTargetModule):
#         self.initLocalVars(_listenTargetModule)
#         if DEBUG:
#             print('setListenTopicTargetModule:')
#             print(_listenTargetModule)
#         self.listenTargetModule = _listenTargetModule

#     def updateLocalVariableValue(self, varName, value):
#         if DEBUG and varName not in getHeavyLocalVarList(self.listenTargetModule):
#             print("update local var:")
#             print(varName)
#             print(value)
#         if self.listenTargetModule not in self.localVarNamesAndValues:
#             return
#         if self.localVarNamesAndValues[self.listenTargetModule][varName] != value:
#             if DEBUG:
#                 print("ACTUAL UPDATE --------------------------------------------------------------------------")
#             self.localVarNamesAndValues[self.listenTargetModule][varName] = value
#             if varName not in getHeavyLocalVarList(self.listenTargetModule):
#                 aos_local_var_collection.replace_one({"Module": self.listenTargetModule, "VarName": varName},
#                                                      {"Module": self.listenTargetModule, "VarName": varName, "Value": value}, upsert=True)
#                 aosStats_local_var_collection.insert_one(
#                     {"Module": self.listenTargetModule, "VarName": varName, "value": value, "Time": datetime.datetime.utcnow()})
#                 if DEBUG:
#                     print("WAS UPDATED --------------------------------------------------------------------------")

# class SharedState1:
#     def __init__(self):
#         self.goal_reached = False




# def main(args=None):
#     rclpy.init(args=args)
#     shared_state = SharedState1()
#     topic_listener = AOS_TopicListenerServer(shared_state)
#     command_listener = ListenToMongoDbCommands(topic_listener,shared_state)

#     topic_listener.get_logger().info("Nodes initialized and command_listener is about to spin")
#     executor = MultiThreadedExecutor()
#     executor.add_node(topic_listener)
#     executor.add_node(command_listener)
#     try:
#         rclpy.spin(command_listener)  # Only spin the command_listener node
#     except KeyboardInterrupt:
#         pass
#     finally:
#         executor.shutdown()
#         command_listener.destroy_node()
#         topic_listener.destroy_node()
#         rclpy.shutdown()

import datetime
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
import pymongo
import traceback
from geometry_msgs.msg import Point
from nav2_msgs.action import NavigateToPose
from rcl_interfaces.msg import Log
from interfaces_robot.srv import NavigateToCoordinates
from rclpy.executors import MultiThreadedExecutor
import time

DEBUG = True
HEAVY_LOCAL_VARS = {}
aosDbConnection = pymongo.MongoClient("mongodb://localhost:27017/")
aosDB = aosDbConnection["AOS"]
aos_statisticsDB = aosDbConnection["AOS_Statistics"]
aos_local_var_collection = aosDB["LocalVariables"]
aosStats_local_var_collection = aos_statisticsDB["LocalVariables"]
aos_GlobalVariablesAssignments_collection = aosDB["GlobalVariablesAssignments"]
aos_ModuleResponses_collection = aosDB["ModuleResponses"]
collActionForExecution = aosDB["ActionsForExecution"]
collLogs = aosDB["Logs"]
collActions = aosDB["Actions"]

def registerError(errorStr, trace, comments=None):
    error = {
        "Component": "RosMiddleware", "Event": errorStr, "Advanced": trace, "LogLevel": 2, "LogLevelDesc": "Error",
        "Time": datetime.datetime.utcnow()
    }
    if comments is not None:
        error = {
            "Component": "RosMiddleware", "Error": errorStr, "Advanced": str(comments) + ". " + str(trace),
            "Time": datetime.datetime.utcnow()
        }
    collLogs.insert_one(error)

def registerLog(logStr):
    log = {
        "Component": "RosMiddleware", "Event": logStr, "LogLevel": 5, "LogLevelDesc": "Debug", "Advanced": "",
        "Time": datetime.datetime.utcnow()
    }
    collLogs.insert_one(log)

def getHeavyLocalVarList(moduleName):
    return HEAVY_LOCAL_VARS.get(moduleName, [])

class ListenToMongoDbCommands(Node):
    def __init__(self, topic_listener,shared_state):
        super().__init__('listen_to_mongodb_commands')
        self.current_action_sequence_id = 1
        self.current_action_for_execution_id = None
        self.shared_state = shared_state
        self.navigate_service_name = "/navigate_to_coordinates"
        self._topicListener = topic_listener
        self.cli = self.create_client(NavigateToCoordinates, self.navigate_service_name)
        
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Service not available, waiting again...')

        self.timer = self.create_timer(1.0, self.listen_to_mongodb_commands)

    def handle_navigate(self, params):
        responseNotByLocalVariables = None
        nav_to_x, nav_to_y, nav_to_z = "", "", ""
        try:
            nav_to_x = params["ParameterValues"]["x"]
            self._topicListener.updateLocalVariableValue("nav_to_x", nav_to_x)
            nav_to_y = params["ParameterValues"]["y"]
            self._topicListener.updateLocalVariableValue("nav_to_y", nav_to_y)
            nav_to_z = params["ParameterValues"]["z"]
            self._topicListener.updateLocalVariableValue("nav_to_z", nav_to_z)
        except Exception as e:
            registerError(str(e), traceback.format_exc(), 'Action: navigate, illegalActionObs')
            responseNotByLocalVariables = "illegalActionObs"
            return responseNotByLocalVariables
    
        try:
            registerLog("wait for service: moduleName=navigate, serviceName=navigate")
            req = NavigateToCoordinates.Request()
            req.x = float(nav_to_x)
            req.y = float(nav_to_y)
            req.z = float(nav_to_z)
            self.get_logger().info("Sending request to service, moduleName=navigate")
            future = self.cli.call_async(req)
            registerLog("Service call made, waiting for response")
            while not self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]:
                          rclpy.spin_once(self._topicListener, timeout_sec=0.1)
            time.sleep(0.1)
            future.add_done_callback(self.navigate_callback)
                        # Wait for the future to complete
            # while not future.done():
            #     rclpy.spin_once(self, timeout_sec=0.1)

            # if future.result() is not None:
            #     result = future.result()
            #     self._topicListener.updateLocalVariableValue("skillSuccess", result.success)
            #     self.shared_state.goal_reached = result.success
            #     if DEBUG:
            #         print("navigate service terminated with success:", result.success)
            # else:
            #     registerError("Service call failed, result is None", "", 'Action: navigate')

            # registerLog("Callback added to future")
        except Exception as e:
            registerError(str(e), traceback.format_exc(), 'Action: navigate')
            print("Service call failed")
    
        return responseNotByLocalVariables

    def navigate_callback(self, future):
        try:
            registerLog("navigate_callback invoked")
            result = future.result()
            registerLog("Future result obtained")
            if result is not None:
                self.get_logger().info("Service response received, moduleName=navigate")
                skillSuccess = result.success
                registerLog(f"Service response success: {skillSuccess}")
                self._topicListener.updateLocalVariableValue("skillSuccess", skillSuccess)
                if DEBUG:
                    print("navigate service terminated")
            else:
                self.get_logger().error("Service call failed, result is None")
                registerLog("Service call failed, result is None")
        except Exception as e:
            registerError(str(e), traceback.format_exc(), 'Action: navigate')
            print("Service call failed")
    

    def saveHeavyLocalVariableToDB(self, moduleName):
        for varName in getHeavyLocalVarList(moduleName):
            value = self._topicListener.localVarNamesAndValues[moduleName][varName]
            aos_local_var_collection.replace_one({"Module": moduleName, "VarName": varName},
                                                 {"Module": moduleName, "VarName": varName,
                                                  "Value": value}, upsert=True)
            aosStats_local_var_collection.insert_one(
                {"Module": moduleName, "VarName": varName, "value": value,
                 "Time": datetime.datetime.utcnow()})

    def registerModuleResponse(self, moduleName, startTime, actionSequenceID, responseNotByLocalVariables):
        registerLog("in the function registerModuleResponse:::::::: ")
        self._topicListener.initLocalVars(moduleName)  # Ensure initialization
        registerLog("in the function registerModuleResponse222222222222:::::::: ")

        self.saveHeavyLocalVariableToDB(moduleName)
        registerLog("in the function registerModuleResponse333333333333333:::::::: ")

        filter1 = {"ActionSequenceId": actionSequenceID}
        # if DEBUG:
            # print("registerModuleResponse()")

        if responseNotByLocalVariables is not None:
            moduleResponseItem = {"Module": moduleName, "ActionSequenceId": actionSequenceID,
                                  "ModuleResponseText": responseNotByLocalVariables, "StartTime": startTime,
                                  "EndTime": datetime.datetime.utcnow(),
                                  "ActionForExecutionId": self.current_action_for_execution_id}
            aos_ModuleResponses_collection.replace_one(filter1, moduleResponseItem, upsert=True)
            return
        registerLog("in the function registerModuleResponse444444444:::::::: ")
        # time.sleep(2)
        moduleResponse = ""
        assignGlobalVar = {}
        if moduleName == "navigate":
            registerLog("in the function registerModuleResponse5555555555:::::::: ")
            skillSuccess = self._topicListener.localVarNamesAndValues["navigate"]["skillSuccess"]
            registerLog("skillSuccess:  "  +  str(skillSuccess))
            registerLog("in the function registerModuleResponse66666666666666666:::::::: ")
            goal_reached = self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]
            registerLog("goal_ReachedValue is  = " + str(goal_reached))
            nav_to_x = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_x"]
            nav_to_y = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_y"]
            nav_to_z = self._topicListener.localVarNamesAndValues["navigate"]["nav_to_z"]
            # skillSuccess and   TOOO ADDD IN THE IFFFFFFFFFF
            if skillSuccess and goal_reached:
                moduleResponse = "navigate_eSuccess"
            else:
                moduleResponse = "navigate_eFailed"
        registerLog("this is the response of the navigation : "+moduleResponse)
        moduleLocalVars = self._topicListener.localVarNamesAndValues.get(moduleName, {})
        moduleResponseItem = {"Module": moduleName, "ActionSequenceId": actionSequenceID,
                              "ModuleResponseText": moduleResponse, "StartTime": startTime, "EndTime": datetime.datetime.utcnow(),
                              "ActionForExecutionId": self.current_action_for_execution_id,
                              "LocalVariables": moduleLocalVars}

        aos_ModuleResponses_collection.replace_one(filter1, moduleResponseItem, upsert=True)
        for varName, value in assignGlobalVar.items():
            isInit = value is not None
            aos_GlobalVariablesAssignments_collection.replace_one({"GlobalVariableName": varName},
                                                                  {"GlobalVariableName": varName, "LowLevelValue": value,
                                                                   "IsInitialized": isInit, "UpdatingActionSequenceId": actionSequenceID,
                                                                   "ModuleResponseId": moduleResponseItem["_id"]}, upsert=True)

    def listen_to_mongodb_commands(self):
        filter1 = {"ActionSequenceId": self.current_action_sequence_id}
        actionForExecution = collActionForExecution.find_one(filter1)
        if actionForExecution:
            if DEBUG:
                print("~~")
                print("actionID:", actionForExecution["ActionID"])
            moduleName = actionForExecution["ActionName"]
            actionParameters = actionForExecution["Parameters"]
            self.current_action_for_execution_id = actionForExecution["_id"]
            registerLog("navigate start with id :::" + str(self.current_action_sequence_id))
            self._topicListener.setListenTarget(moduleName)
            time.sleep(0.3)
            moduleActivationStart = datetime.datetime.utcnow()
            responseNotByLocalVariables = None
            print("module name:", moduleName)
            registerLog("Request to call to module: " + moduleName)
            registerLog("navigate start:")
            if moduleName == "navigate":
                print("handle navigate")
                responseNotByLocalVariables = self.handle_navigate(actionParameters)
            registerLog("navigate finished:")
            time.sleep(0.3)
            self._topicListener.setListenTarget("after action")
            # while not self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]:
            #               rclpy.spin_once(self._topicListener, timeout_sec=0.1)
 
            registerLog("after while loop of goal reached"+ str(self._topicListener.localVarNamesAndValues["navigate"]["goal_reached"]))    
            self.registerModuleResponse(moduleName, moduleActivationStart, self.current_action_sequence_id,
                                        responseNotByLocalVariables)
            if DEBUG:
                print("navigate finished")
            self.current_action_sequence_id += 1
            self.currentActionFotExecutionId = None
    time.sleep(0.1)        

class AOS_TopicListenerServer(Node):
    def __init__(self,shared_state):
        super().__init__('aos_topic_listener_server')
        print("NAAAAAAAAAAAATAASHHHHHHKAa")
        self.shared_state = shared_state
        self.localVarNamesAndValues = {"navigate": {"skillSuccess": None, "goal_reached": False, "nav_to_x": None, "nav_to_y": None, "nav_to_z": None}}
        self.setListenTarget("initTopicListener")
        self.subscription = self.create_subscription(Log, '/rosout', self.cb__rosout, 10)
        print("LOLO")
        self.get_logger().info("AOS_TopicListenerServer initialized and subscribed to /rosout")
        
    def cb__rosout(self, msg):
        print("NAtaaaaaaaaaaaashshshshshshshshsha")
        try:
            print("44444444444444444444444444444")
            print(self.listenTargetModule)
            if self.listenTargetModule == "navigate":
                if DEBUG:
                    print("handling topic call:navigate")
                    print(msg)
                print("checkinggg valuesssssssssssssssssssss")    
                value = self.navigate_get_value_goal_succeeded(msg)
                print("this is the value of goalllll reached :"+ str(value))
                self.updateLocalVariableValue("goal_reached", value)
                self.updateLocalVariableValue("skillSuccess", value)#should be changed 

        except Exception as e:
            registerError(str(e), traceback.format_exc(), 'topic /rosout')

    def navigate_get_value_goal_succeeded(self, __input):
        if 'Goal has been reached.' in __input.msg:
            # print("checkinggg valuesssssssssssssssssssss2222222222222222222222222222222222222")    
            # registerLog("goalllllllll reacheddd")            
            # print("Goal succeeded detected in message")
            self.shared_state.goal_reached = True
            self.skill_success=True #should be changed 
            return True
        return False

    def initLocalVars(self, moduleNameToInit):
        # if DEBUG:
            # print("initLocalVars:")
            # print(moduleNameToInit)
        for moduleName, localVarNamesAndValuesPerModule in self.localVarNamesAndValues.items():
            for localVarName, value in localVarNamesAndValuesPerModule.items():
                if moduleName == moduleNameToInit:
                    # if DEBUG:
                        # print("init var:")
                        # print(localVarName)
                    aos_local_var_collection.replace_one({"Module": moduleName, "VarName": localVarName},
                                                         {"Module": moduleName, "VarName": localVarName, "Value": value},
                                                         upsert=True)
                    aosStats_local_var_collection.insert_one(
                        {"Module": moduleName, "VarName": localVarName, "value": value, "Time": datetime.datetime.utcnow()})

    def setListenTarget(self, _listenTargetModule):
        self.initLocalVars(_listenTargetModule)
        if DEBUG:
            print('setListenTopicTargetModule:')
            print(_listenTargetModule)
        self.listenTargetModule = _listenTargetModule

    def updateLocalVariableValue(self, varName, value):
        if DEBUG and varName not in getHeavyLocalVarList(self.listenTargetModule):
            print("update local var:")
            print(varName)
            print(value)
        if self.listenTargetModule not in self.localVarNamesAndValues:
            return
        if self.localVarNamesAndValues[self.listenTargetModule][varName] != value:
            if DEBUG:
                print("ACTUAL UPDATE --------------------------------------------------------------------------")
            self.localVarNamesAndValues[self.listenTargetModule][varName] = value
            if varName not in getHeavyLocalVarList(self.listenTargetModule):
                aos_local_var_collection.replace_one({"Module": self.listenTargetModule, "VarName": varName},
                                                     {"Module": self.listenTargetModule, "VarName": varName, "Value": value}, upsert=True)
                aosStats_local_var_collection.insert_one(
                    {"Module": self.listenTargetModule, "VarName": varName, "value": value, "Time": datetime.datetime.utcnow()})
                if DEBUG:
                    print("WAS UPDATED --------------------------------------------------------------------------")

class SharedState1:
    def __init__(self):
        self.goal_reached = False
        self.skill_success=False#should be changed 



def main(args=None):
    rclpy.init(args=args)
    shared_state = SharedState1()
    topic_listener = AOS_TopicListenerServer(shared_state)
    command_listener = ListenToMongoDbCommands(topic_listener,shared_state)

    topic_listener.get_logger().info("Nodes initialized and command_listener is about to spin")
    executor = MultiThreadedExecutor()
    executor.add_node(topic_listener)
    executor.add_node(command_listener)
    try:
        rclpy.spin(command_listener)  # Only spin the command_listener node
    except KeyboardInterrupt:
        pass
    finally:
        executor.shutdown()
        command_listener.destroy_node()
        topic_listener.destroy_node()
        rclpy.shutdown()



