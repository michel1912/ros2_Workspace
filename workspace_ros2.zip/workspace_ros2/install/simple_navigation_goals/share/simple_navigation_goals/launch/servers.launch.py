

from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription,TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    ld = LaunchDescription()

    # Include turtlebot3 world launch
    turtlebot3_gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([get_package_share_directory('turtlebot3_gazebo'), '/launch/turtlebot3_world.launch.py'])
    )
    ld.add_action(turtlebot3_gazebo_launch)

    # Include turtlebot3 navigation2 launch
    turtlebot3_navigation2_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([get_package_share_directory('turtlebot3_navigation2'), '/launch/navigation2.launch.py']),
        launch_arguments={'map_file': '$/home/map.yaml'}.items()
    )
    ld.add_action(turtlebot3_navigation2_launch)



    # Add navigate_server node
    ld.add_action(Node(
       package='simple_navigation_goals',
       executable='initialPose',
       name='initialPose',
       output='screen'
     ))
    
        # Add navigate_server node
    ld.add_action(Node(
        package='simple_navigation_goals',
        executable='navigate_to_coordinates_service',
        name='navigate_to_coordinates_service',
        output='screen'
      ))

    return ld


# from launch import LaunchDescription
# from launch_ros.actions import Node
# from launch.actions import IncludeLaunchDescription, TimerAction
# from launch.launch_description_sources import PythonLaunchDescriptionSource
# from ament_index_python.packages import get_package_share_directory

# def generate_launch_description():
#     ld = LaunchDescription()

#     # Include turtlebot3 world launch
#     turtlebot3_gazebo_launch = IncludeLaunchDescription(
#         PythonLaunchDescriptionSource([get_package_share_directory('turtlebot3_gazebo'), '/launch/turtlebot3_world.launch.py'])
#     )
#     ld.add_action(turtlebot3_gazebo_launch)

#     # Include turtlebot3 navigation2 launch
#     turtlebot3_navigation2_launch = IncludeLaunchDescription(
#         PythonLaunchDescriptionSource([get_package_share_directory('turtlebot3_navigation2'), '/launch/navigation2.launch.py']),
#         launch_arguments={'map_file': '$/home/map.yaml'}.items()
#     )
#     ld.add_action(turtlebot3_navigation2_launch)



#     # Node to publish initial pose
#     initial_pose_publisher = Node(
#         package='simple_navigation_goals',  # Replace with your package name
#         executable='initialPose',  # Replace with your executable name
#         name='initialPose',
#         output='screen',
#         parameters=[{'use_sim_time': True}],
#     )

#     # Delayed start of initial_pose_publisher to ensure all nodes are ready
#     delayed_initial_pose_publisher = TimerAction(
#         period=5.0,  # Wait for 5 seconds
#         actions=[initial_pose_publisher]
#     )
#     ld.add_action(delayed_initial_pose_publisher)

#     return ld
