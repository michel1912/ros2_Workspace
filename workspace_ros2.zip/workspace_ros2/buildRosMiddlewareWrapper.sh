#!/bin/bash

cd /home/michel/workspace_ros2
colcon build
source ~/.bashrc